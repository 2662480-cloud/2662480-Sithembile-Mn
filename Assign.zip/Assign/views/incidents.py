"""c) Safety Incident Database."""

from datetime import date, time

import plotly.express as px
import streamlit as st

from src import config, data_loader, incidents as incidents_mod
from views import shared


def render() -> None:
    shared.section_header("🚨 Safety Incident Database")

    tab_search, tab_add, tab_trends = st.tabs(["Search / View", "Add Incident", "Analyse Trends"])

    with tab_search:
        f1, f2, f3, f4 = st.columns(4)
        search_text = f1.text_input("Search location / cause")
        department = f2.selectbox("Department", ["All"] + config.DEPARTMENTS)
        shift = f3.selectbox("Shift", ["All"] + config.SHIFTS)
        status = f4.selectbox("Status", ["All"] + sorted(incidents_mod.VALID_STATUS))

        results = incidents_mod.search_incidents(
            search_text=search_text or None,
            department=None if department == "All" else department,
            shift=None if shift == "All" else shift,
            status=None if status == "All" else status,
        )
        st.caption(f"{len(results)} incident(s)")
        st.dataframe(shared.style_status_columns(results, ["incident_status", "injury_status"]),
                     width='stretch', hide_index=True)

    with tab_add:
        workers_df = data_loader.load_workers()
        worker_ids = ["(none)"] + list(workers_df["worker_id"]) if not workers_df.empty else ["(none)"]

        with st.form("add_incident_form", clear_on_submit=True):
            c1, c2, c3 = st.columns(3)
            worker_id = c1.selectbox("Worker involved", worker_ids)
            incident_date = c2.date_input("Date", value=date.today())
            incident_time = c3.time_input("Time", value=time(8, 0))

            c4, c5, c6 = st.columns(3)
            shift = c4.selectbox("Shift", config.SHIFTS)
            location = c5.text_input("Location")
            department = c6.selectbox("Department", config.DEPARTMENTS)

            c7, c8 = st.columns(2)
            incident_type = c7.text_input("Incident type", placeholder="e.g. Fall, Fire, Slip/Trip")
            severity = c8.slider("Severity (1-5)", 1, 5, 2)

            c9, c10 = st.columns(2)
            injury_status = c9.selectbox("Injury status", ["None", "First Aid", "Medical Treatment", "Lost Time"])
            lost_time_injury = c10.checkbox("Lost-time injury")

            cause = st.text_input("Cause")
            corrective_action = st.text_area("Corrective action")
            incident_status = st.selectbox("Status", sorted(incidents_mod.VALID_STATUS))

            submitted = st.form_submit_button("Log incident", width='stretch')

        if submitted:
            incident_id, error = incidents_mod.add_incident(
                worker_id=None if worker_id == "(none)" else worker_id,
                date=str(incident_date), time=incident_time.strftime("%H:%M"),
                shift=shift, location=location, department=department,
                incident_type=incident_type, severity=int(severity),
                injury_status=injury_status, lost_time_injury=lost_time_injury,
                cause=cause, corrective_action=corrective_action,
                incident_status=incident_status,
            )
            if error:
                st.error(error)
            else:
                st.success(f"Incident {incident_id} logged.")
                if severity >= 4:
                    st.warning("Critical incident alert raised.")
                st.rerun()

    with tab_trends:
        trends = incidents_mod.analyse_incident_trends()
        col1, col2 = st.columns(2)
        with col1:
            if len(trends["by_department"]):
                fig = px.bar(x=trends["by_department"].index, y=trends["by_department"].values,
                             labels={"x": "Department", "y": "Incidents"}, title="By department")
                st.plotly_chart(fig, width='stretch')
        with col2:
            if len(trends["by_shift"]):
                fig = px.pie(values=trends["by_shift"].values, names=trends["by_shift"].index,
                             title="By shift")
                st.plotly_chart(fig, width='stretch')

        if len(trends["by_type"]):
            fig = px.bar(x=trends["by_type"].index, y=trends["by_type"].values,
                         labels={"x": "Incident type", "y": "Count"}, title="By type")
            st.plotly_chart(fig, width='stretch')

        st.metric("High/Critical severity incidents (severity >= 4)", trends["high_critical_count"])
