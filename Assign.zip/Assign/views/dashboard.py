"""i) Mining Monitoring Dashboard."""

import pandas as pd
import plotly.express as px
import streamlit as st

from src import alerts as alerts_mod
from src import data_loader, incidents, maintenance, rules
from views import shared


def render() -> None:
    shared.section_header("📊 Mining Monitoring Dashboard")

    workers = data_loader.load_workers()
    incidents_df = data_loader.load_incidents()
    equipment = data_loader.load_equipment()

    # --- Worker / safety KPIs -------------------------------------------
    st.subheader("Health & Safety")
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total workers", len(workers))
    c2.metric("Total incidents", len(incidents_df))
    c3.metric("Near misses (total)", int(workers["near_misses"].sum()) if not workers.empty else 0)
    c4.metric("High/Critical risk workers",
              int(workers["risk_level"].isin(["High", "Critical"]).sum()) if not workers.empty else 0)
    c5.metric("Avg PPE compliance %",
              f"{workers['ppe_compliance_pct'].mean():.1f}" if not workers.empty else "—")

    # --- Equipment KPIs ---------------------------------------------------
    st.subheader("Equipment")
    e1, e2, e3, e4, e5 = st.columns(5)
    e1.metric("Total equipment", len(equipment))
    e2.metric("Up to date", int((equipment["maintenance_status"] == "Up to date").sum()) if not equipment.empty else 0)
    e3.metric("Under maintenance",
              int((equipment["maintenance_status"] == "Under Maintenance").sum()) if not equipment.empty else 0)
    if not equipment.empty:
        avg_availability = equipment.apply(
            lambda r: rules.calculate_availability(r["operating_hours"], r["downtime_hours"]), axis=1
        ).mean()
    else:
        avg_availability = None
    e4.metric("Avg availability %", f"{avg_availability:.1f}" if avg_availability is not None else "—")
    e5.metric("Active / critical alerts",
              f"{alerts_mod.count_active_alerts()} / {alerts_mod.count_critical_alerts()}")

    st.divider()

    # --- Charts -------------------------------------------------------
    col1, col2 = st.columns(2)
    with col1:
        trends = incidents.analyse_incident_trends(incidents_df)
        by_dept = trends["by_department"]
        if len(by_dept):
            fig = px.bar(x=by_dept.index, y=by_dept.values,
                         labels={"x": "Department", "y": "Incidents"},
                         title="Incidents by department")
            st.plotly_chart(fig, width='stretch')
        else:
            st.info("No incident data yet.")

    with col2:
        if not equipment.empty:
            status_counts = equipment["maintenance_status"].value_counts()
            fig = px.pie(values=status_counts.values, names=status_counts.index,
                         title="Equipment status breakdown")
            st.plotly_chart(fig, width='stretch')
        else:
            st.info("No equipment data yet.")

    st.subheader("Equipment needing attention")
    attention = maintenance.equipment_needing_attention()
    if attention.empty:
        st.success("No equipment currently flagged.")
    else:
        st.dataframe(shared.style_status_columns(attention, ["flags"]), width='stretch')
