"""Shared Streamlit helpers used across every page."""

import pandas as pd
import streamlit as st

from src import alerts as alerts_mod

STATUS_COLORS = {
    "Critical": "#f8d0d0", "High": "#fbe0b3", "Fault": "#f8d0d0", "Overdue": "#f8d0d0",
    "Warning": "#fdf0b0", "Medium": "#fdf0b0", "Due": "#fdf0b0", "Due Soon": "#fdf0b0",
    "Under Maintenance": "#fdf0b0",
    "Normal": "#d9f2d9", "Low": "#d9f2d9", "OK": "#d9f2d9", "Up to date": "#d9f2d9",
}


def style_status_columns(df: pd.DataFrame, columns: list[str]):
    """Return a pandas Styler that colors cells in `columns` by status/severity value."""
    present = [c for c in columns if c in df.columns]
    if not present:
        return df

    def _color(val):
        color = STATUS_COLORS.get(str(val))
        return f"background-color: {color}" if color else ""

    return df.style.map(_color, subset=present)


def render_alert_banner(limit: int = 5) -> None:
    """Shown at the top of every page: unacknowledged Critical alerts."""
    critical = alerts_mod.list_alerts(active_only=True, severity="Critical")
    if critical.empty:
        return
    st.error(f"🚨 {len(critical)} unacknowledged CRITICAL alert(s) — see Alerts page.")
    with st.expander("Preview critical alerts", expanded=False):
        for _, row in critical.head(limit).iterrows():
            st.code(row["message"])


def section_header(title: str, caption: str | None = None) -> None:
    st.title(title)
    if caption:
        st.caption(caption)
    render_alert_banner()
