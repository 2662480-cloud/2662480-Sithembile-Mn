"""b) Worker Health and Safety Monitoring."""

import streamlit as st

from src import config, workers as workers_mod
from views import shared


def render() -> None:
    shared.section_header("🧑‍🏭 Worker Health & Safety Monitoring")

    tab_view, tab_add = st.tabs(["View / Filter Workers", "Add Worker"])

    with tab_view:
        summary = workers_mod.unsafe_conditions_summary()
        c1, c2, c3 = st.columns(3)
        c1.metric("Low PPE compliance (<70%)", summary["low_ppe_compliance"])
        c2.metric("High fatigue (>=4)", summary["high_fatigue"])
        c3.metric("High/Critical risk", summary["high_risk_workers"])

        f1, f2, f3 = st.columns(3)
        department = f1.selectbox("Department", ["All"] + config.DEPARTMENTS)
        shift = f2.selectbox("Shift", ["All"] + config.SHIFTS)
        risk_level = f3.selectbox("Risk level", ["All", "Low", "Medium", "High", "Critical"])

        results = workers_mod.view_workers(
            department=None if department == "All" else department,
            shift=None if shift == "All" else shift,
            risk_level=None if risk_level == "All" else risk_level,
        )
        st.caption(f"{len(results)} worker(s)")
        st.dataframe(shared.style_status_columns(results, ["risk_level", "safety_training_status"]),
                     width='stretch', hide_index=True)

    with tab_add:
        with st.form("add_worker_form", clear_on_submit=True):
            name = st.text_input("Name")
            c1, c2, c3 = st.columns(3)
            department = c1.selectbox("Department", config.DEPARTMENTS)
            job_role = c2.text_input("Job role")
            shift = c3.selectbox("Shift", config.SHIFTS)

            c4, c5 = st.columns(2)
            ppe_compliance_pct = c4.slider("PPE compliance %", 0, 100, 90)
            training_status = c5.selectbox("Safety training status", sorted(workers_mod.VALID_TRAINING_STATUS))

            c6, c7, c8, c9 = st.columns(4)
            fatigue_level = c6.slider("Fatigue level (1-5)", 1, 5, 2)
            safety_observations = c7.number_input("Safety observations", min_value=0, value=0, step=1)
            near_misses = c8.number_input("Near misses", min_value=0, value=0, step=1)
            previous_incidents = c9.number_input("Previous incidents", min_value=0, value=0, step=1)

            submitted = st.form_submit_button("Add worker", width='stretch')

        if submitted:
            worker_id, error = workers_mod.add_worker(
                name=name, department=department, job_role=job_role, shift=shift,
                ppe_compliance_pct=float(ppe_compliance_pct),
                safety_training_status=training_status,
                fatigue_level=int(fatigue_level),
                safety_observations=int(safety_observations),
                near_misses=int(near_misses),
                previous_incidents=int(previous_incidents),
            )
            if error:
                st.error(error)
            else:
                st.success(f"Worker {worker_id} added.")
                st.rerun()
