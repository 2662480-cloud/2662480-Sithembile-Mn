"""f) Equipment Maintenance Monitoring."""

from datetime import date, timedelta

import streamlit as st

from src import data_loader, maintenance as maintenance_mod
from views import shared


def render() -> None:
    shared.section_header("🛠️ Equipment Maintenance Monitoring")

    tab_status, tab_add, tab_complete = st.tabs(
        ["Maintenance Status", "Add Maintenance Record", "Complete Record"]
    )

    with tab_status:
        raise_alerts = st.button("Run maintenance monitoring check (raises alerts for Overdue/Repeated Alerts)")
        summary = maintenance_mod.run_maintenance_monitoring(raise_alerts=raise_alerts)
        if raise_alerts:
            st.success("Maintenance monitoring check complete — alerts raised where applicable.")

        if summary.empty:
            st.info("No equipment data yet.")
        else:
            st.subheader("Needs attention")
            attention = maintenance_mod.equipment_needing_attention(summary)
            if attention.empty:
                st.success("Nothing flagged.")
            else:
                st.dataframe(shared.style_status_columns(attention, ["flags"]),
                             width='stretch', hide_index=True)

            st.subheader("All equipment")
            st.dataframe(shared.style_status_columns(summary, ["flags"]),
                         width='stretch', hide_index=True)

    with tab_add:
        equipment_df = data_loader.load_equipment()
        equipment_ids = list(equipment_df["equipment_id"]) if not equipment_df.empty else []

        with st.form("add_maintenance_form", clear_on_submit=True):
            equipment_id = st.selectbox("Equipment", equipment_ids)
            c1, c2 = st.columns(2)
            scheduled_date = c1.date_input("Scheduled date", value=date.today())
            next_due_date = c2.date_input("Next due date", value=date.today() + timedelta(days=90))

            maintenance_type = st.selectbox("Maintenance type", ["Preventive", "Corrective", "Inspection"])
            description = st.text_area("Description")
            technician = st.text_input("Technician")
            status = st.selectbox("Status", ["Scheduled", "Due", "Overdue", "In Progress"])

            submitted = st.form_submit_button("Add record", width='stretch')

        if submitted:
            if not equipment_ids:
                st.error("Add equipment first.")
            else:
                maintenance_id, error = maintenance_mod.add_maintenance_record(
                    equipment_id=equipment_id, scheduled_date=str(scheduled_date),
                    maintenance_type=maintenance_type, description=description,
                    technician=technician, next_due_date=str(next_due_date), status=status,
                )
                if error:
                    st.error(error)
                else:
                    st.success(f"Maintenance record {maintenance_id} added.")
                    st.rerun()

    with tab_complete:
        records = data_loader.load_maintenance()
        outstanding = records[records["status"] != "Completed"] if not records.empty else records
        if outstanding.empty:
            st.info("No outstanding maintenance records.")
        else:
            st.dataframe(outstanding, width='stretch', hide_index=True)
            with st.form("complete_maintenance_form"):
                maintenance_id = st.selectbox("Maintenance record", list(outstanding["maintenance_id"]))
                completed_date = st.date_input("Completed date", value=date.today())
                submitted = st.form_submit_button("Mark completed", width='stretch')
            if submitted:
                ok = maintenance_mod.complete_maintenance_record(maintenance_id, str(completed_date))
                if ok:
                    st.success(f"{maintenance_id} marked completed; equipment status updated.")
                    st.rerun()
                else:
                    st.error("Could not find that maintenance record.")
