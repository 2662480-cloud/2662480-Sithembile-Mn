"""j) Interactive Data Analysis."""

import pandas as pd
import plotly.express as px
import streamlit as st

from src import analysis
from views import shared


def _render_result(result: dict) -> None:
    if result["result_type"] == "metric":
        st.metric(result["title"], result["value"])
        return

    if result["result_type"] == "table":
        st.subheader(result["title"])
        data = result["data"]
        if data.empty:
            st.info("No data available yet.")
        else:
            st.dataframe(data, width='stretch', hide_index=True)
        return

    if result["result_type"] == "chart":
        st.subheader(result["title"])
        series: pd.Series = result["series"]
        if series.empty:
            st.info("No data available yet.")
            return
        kind = result["chart_kind"]
        if kind == "bar":
            fig = px.bar(x=series.index.astype(str), y=series.values,
                         labels={"x": "", "y": "Count"})
        elif kind == "pie":
            fig = px.pie(values=series.values, names=series.index.astype(str))
        else:  # line
            fig = px.line(x=series.index.astype(str), y=series.values,
                          labels={"x": "", "y": "Count"}, markers=True)
        st.plotly_chart(fig, width='stretch')


def render() -> None:
    shared.section_header("📈 Interactive Data Analysis",
                           "Pick a business question — mirrors Appendix A of the project brief.")

    category = st.selectbox("Category", analysis.CATEGORIES)
    options = {k: v["label"] for k, v in analysis.QUESTION_REGISTRY.items() if v["category"] == category}
    question_key = st.selectbox("Question", list(options.keys()), format_func=lambda k: options[k])

    result = analysis.answer_question(question_key)
    _render_result(result)
