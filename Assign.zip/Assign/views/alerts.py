"""h) Alerts and Notifications."""

import streamlit as st

from src import alerts as alerts_mod


def render() -> None:
    st.title("🔔 Alerts & Notifications")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Active alerts", alerts_mod.count_active_alerts())
    c2.metric("Critical (active)", alerts_mod.count_critical_alerts())
    active_only = c3.checkbox("Show active only", value=True)
    severity = c4.selectbox("Severity", ["All", "Critical", "Warning", "High", "Medium", "Low"])

    results = alerts_mod.list_alerts(
        active_only=active_only,
        severity=None if severity == "All" else severity,
    )

    if results.empty:
        st.success("No alerts to show.")
        return

    st.caption(f"{len(results)} alert(s)")
    for _, row in results.head(50).iterrows():
        color = "red" if row["severity"] == "Critical" else "orange"
        with st.container(border=True):
            top = st.columns([5, 1])
            top[0].markdown(
                f":{color}[**[{row['severity']}]**] `{row['source_type']} {row['source_id']}` — "
                f"{row['parameter']}: {row['value']}  \n"
                f"<small>{row['timestamp']}</small>",
                unsafe_allow_html=True,
            )
            acknowledged = bool(row["acknowledged"]) if not str(row["acknowledged"]) == "nan" else False
            if not acknowledged:
                if top[1].button("Acknowledge", key=f"ack_{row['alert_id']}"):
                    alerts_mod.acknowledge_alert(row["alert_id"])
                    st.rerun()
            else:
                top[1].caption("✅ Acked")
