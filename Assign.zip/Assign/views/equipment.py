"""d) Equipment Database + e) Equipment Condition Monitoring."""

import streamlit as st

from src import condition_monitoring, config, equipment as equipment_mod
from views import shared

MAINTENANCE_STATUSES = ["Up to date", "Due", "Overdue", "Under Maintenance"]


def render() -> None:
    shared.section_header("🚜 Equipment Database & Condition Monitoring")

    tab_view, tab_add, tab_condition = st.tabs(
        ["View Equipment", "Add / Update Equipment", "Condition Monitoring"]
    )

    with tab_view:
        f1, f2 = st.columns(2)
        eq_type = f1.selectbox("Equipment type", ["All"] + config.EQUIPMENT_TYPES)
        eq_status = f2.selectbox("Maintenance status", ["All"] + MAINTENANCE_STATUSES)

        results = equipment_mod.view_equipment(
            equipment_type=None if eq_type == "All" else eq_type,
            maintenance_status=None if eq_status == "All" else eq_status,
        )
        st.caption(f"{len(results)} item(s)")
        st.dataframe(
            shared.style_status_columns(
                results, ["brake_status", "tyre_status", "engine_status", "maintenance_status"]
            ),
            width='stretch', hide_index=True,
        )

    with tab_add:
        with st.form("add_equipment_form"):
            c1, c2, c3 = st.columns(3)
            equipment_id = c1.text_input("Equipment ID", placeholder="e.g. TRK-012")
            equipment_type = c2.selectbox("Equipment type", config.EQUIPMENT_TYPES)
            manufacturer = c3.text_input("Manufacturer")

            c4, c5, c6 = st.columns(3)
            operating_hours = c4.number_input("Operating hours", min_value=0.0, value=0.0)
            downtime_hours = c5.number_input("Downtime hours", min_value=0.0, value=0.0)
            fuel_consumption = c6.number_input("Fuel consumption (l/hr)", min_value=0.0, value=0.0)

            c7, c8 = st.columns(2)
            temperature = c7.number_input("Temperature (°C)", value=60.0)
            vibration = c8.number_input("Vibration (mm/s)", value=2.0)

            c9, c10, c11 = st.columns(3)
            brake_status = c9.selectbox("Brake status", sorted(equipment_mod.VALID_STATUS))
            tyre_status = c10.selectbox("Tyre status", sorted(equipment_mod.VALID_STATUS))
            engine_status = c11.selectbox("Engine status", sorted(equipment_mod.VALID_STATUS))

            maintenance_status = st.selectbox("Maintenance status", MAINTENANCE_STATUSES)

            submitted = st.form_submit_button("Save equipment", width='stretch')

        if submitted:
            ok, error = equipment_mod.add_or_update_equipment(
                equipment_id=equipment_id, equipment_type=equipment_type, manufacturer=manufacturer,
                operating_hours=operating_hours, temperature=temperature, vibration=vibration,
                fuel_consumption=fuel_consumption, brake_status=brake_status, tyre_status=tyre_status,
                engine_status=engine_status, maintenance_status=maintenance_status,
                downtime_hours=downtime_hours,
            )
            if error:
                st.error(error)
            else:
                st.success(f"Equipment {equipment_id} saved.")
                st.rerun()

    with tab_condition:
        st.caption("Evaluates current temperature/vibration readings against warning/critical thresholds.")
        raise_alerts = st.button("Run condition monitoring check (raises alerts for Warning/Critical)")
        summary = condition_monitoring.run_condition_monitoring(raise_alerts=raise_alerts)
        if raise_alerts:
            st.success("Condition monitoring check complete — alerts raised where applicable.")
        if summary.empty:
            st.info("No equipment data yet.")
        else:
            st.dataframe(
                shared.style_status_columns(summary, ["temperature_status", "vibration_status", "overall_status"]),
                width='stretch', hide_index=True,
            )
