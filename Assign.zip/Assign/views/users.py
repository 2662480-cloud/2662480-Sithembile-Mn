"""Administrator-only: manage user accounts (RBAC support for function a)."""

import streamlit as st

from src import auth, config, data_loader


def render() -> None:
    st.title("🔐 Manage Users")

    users = data_loader.load_users()
    display = users.drop(columns=["password_hash"]) if not users.empty else users
    st.dataframe(display, width='stretch', hide_index=True)

    st.subheader("Add user")
    with st.form("add_user_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        username = c1.text_input("Username")
        full_name = c2.text_input("Full name")
        c3, c4 = st.columns(2)
        role = c3.selectbox("Role", config.ROLES)
        password = c4.text_input("Password", type="password", value="password123")
        submitted = st.form_submit_button("Add user", width='stretch')

    if submitted:
        if not users.empty and (users["username"] == username).any():
            st.error("Username already exists")
        elif not username or not full_name:
            st.error("Username and full name are required")
        else:
            user_id = data_loader.next_id(config.USERS_CSV, "user_id", "U")
            data_loader.append_row(config.USERS_CSV, {
                "user_id": user_id, "username": username,
                "password_hash": auth.hash_password(password),
                "full_name": full_name, "role": role, "active": True,
            })
            st.success(f"User {user_id} ({username}) added.")
            st.rerun()

    st.subheader("Enable / disable a user")
    if not users.empty:
        target = st.selectbox("User", list(users["username"]))
        record = users[users["username"] == target].iloc[0]
        currently_active = bool(record["active"])
        st.write(f"Currently: {'Active' if currently_active else 'Disabled'}")
        if st.button("Toggle active status"):
            data_loader.update_row(config.USERS_CSV, "user_id", record["user_id"],
                                    {"active": not currently_active})
            st.rerun()
