"""g) Risk Assessment."""

import streamlit as st

from src import data_loader, risk as risk_mod
from views import shared


def _related_id_options(related_type: str) -> list[str]:
    if related_type == "Worker":
        df = data_loader.load_workers()
        return list(df["worker_id"]) if not df.empty else []
    if related_type == "Equipment":
        df = data_loader.load_equipment()
        return list(df["equipment_id"]) if not df.empty else []
    if related_type == "Incident":
        df = data_loader.load_incidents()
        return list(df["incident_id"]) if not df.empty else []
    from src import config
    return config.DEPARTMENTS


def render() -> None:
    shared.section_header("⚠️ Risk Assessment")

    session = st.session_state.session

    with st.form("risk_assessment_form"):
        related_type = st.selectbox("Assess risk for", sorted(risk_mod.VALID_RELATED_TYPES))
        options = _related_id_options(related_type)
        related_id = st.selectbox("Related ID", options) if options else st.text_input("Related ID")

        c1, c2 = st.columns(2)
        likelihood = c1.slider("Likelihood (1-5)", 1, 5, 3)
        consequence = c2.slider("Consequence (1-5)", 1, 5, 3)

        st.caption(f"Risk score preview: {likelihood * consequence}")

        submitted = st.form_submit_button("Submit assessment", width='stretch')

    if submitted:
        result, error = risk_mod.submit_risk_assessment(
            related_type=related_type, related_id=related_id,
            likelihood=int(likelihood), consequence=int(consequence),
            assessed_by=session.user_id,
        )
        if error:
            st.error(error)
        else:
            st.success(f"Risk {result['risk_id']} recorded — score {result['risk_score']} "
                       f"({result['classification']}).")
            if result["warning"]:
                st.warning(f"High/Critical risk identified for {related_type} {related_id}.")
            st.rerun()

    st.divider()
    st.subheader("Recorded risk assessments")
    f1, f2 = st.columns(2)
    filter_type = f1.selectbox("Filter by type", ["All"] + sorted(risk_mod.VALID_RELATED_TYPES))
    filter_class = f2.selectbox("Filter by classification", ["All", "Low", "Medium", "High", "Critical"])

    results = risk_mod.list_risk_assessments(
        related_type=None if filter_type == "All" else filter_type,
        classification=None if filter_class == "All" else filter_class,
    )
    st.dataframe(shared.style_status_columns(results, ["classification"]),
                 width='stretch', hide_index=True)
