"""
Generic CSV data-access layer.

Every entity (workers, incidents, equipment, ...) is a CSV file under data/.
This module is the ONLY place that touches the filesystem for that data -
everything else (rules, pages, generator) reads/writes through these
functions, so swapping CSV for SQLite later only means changing this file.
"""

from pathlib import Path
import pandas as pd

from src import config


def ensure_data_dir() -> None:
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)


def load_csv(path: Path) -> pd.DataFrame:
    """Load a CSV as a DataFrame. If it doesn't exist yet, return an empty
    DataFrame with the correct columns (from config.SCHEMAS)."""
    ensure_data_dir()
    columns = config.SCHEMAS[path]
    if not path.exists():
        return pd.DataFrame(columns=columns)
    df = pd.read_csv(path)
    for col in columns:
        if col not in df.columns:
            df[col] = pd.NA
    return df[columns]


def save_csv(path: Path, df: pd.DataFrame) -> None:
    ensure_data_dir()
    columns = config.SCHEMAS[path]
    df.to_csv(path, index=False, columns=columns)


def append_row(path: Path, row: dict) -> None:
    df = load_csv(path)
    new_row = pd.DataFrame([row])
    df = pd.concat([df, new_row], ignore_index=True)
    save_csv(path, df)


def update_row(path: Path, id_column: str, id_value, updates: dict) -> bool:
    """Update the first row matching id_column == id_value. Returns True if a row was updated."""
    df = load_csv(path)
    mask = df[id_column] == id_value
    if not mask.any():
        return False
    for key, value in updates.items():
        # A column that has only ever held blanks (e.g. completed_date on a
        # freshly-scheduled record) gets inferred as float64/NaN by
        # read_csv. Writing a string into it then raises a pandas
        # LossySetitemError, so widen to object first - this never touches
        # the CSV, which has no dtypes anyway.
        if key in df.columns and df[key].dtype != object:
            df[key] = df[key].astype(object)
        df.loc[mask, key] = value
    save_csv(path, df)
    return True


def next_id(path: Path, id_column: str, prefix: str, width: int = 3) -> str:
    """Generate the next sequential ID like 'W001', 'EQ014', based on existing rows."""
    df = load_csv(path)
    if df.empty or id_column not in df.columns:
        return f"{prefix}{1:0{width}d}"
    existing_numbers = []
    for value in df[id_column].dropna():
        value = str(value)
        digits = "".join(ch for ch in value if ch.isdigit())
        if digits:
            existing_numbers.append(int(digits))
    next_number = (max(existing_numbers) + 1) if existing_numbers else 1
    return f"{prefix}{next_number:0{width}d}"


# --- Typed convenience loaders (one per entity) -------------------------

def load_users() -> pd.DataFrame:
    return load_csv(config.USERS_CSV)


def load_workers() -> pd.DataFrame:
    return load_csv(config.WORKERS_CSV)


def load_incidents() -> pd.DataFrame:
    return load_csv(config.INCIDENTS_CSV)


def load_equipment() -> pd.DataFrame:
    return load_csv(config.EQUIPMENT_CSV)


def load_maintenance() -> pd.DataFrame:
    return load_csv(config.MAINTENANCE_CSV)


def load_risk_assessments() -> pd.DataFrame:
    return load_csv(config.RISK_CSV)


def load_alerts() -> pd.DataFrame:
    return load_csv(config.ALERTS_CSV)
