"""
f) Equipment Maintenance Monitoring.
"""

from datetime import date, datetime, timedelta

import pandas as pd

from src import alerts, config, data_loader, rules


def add_maintenance_record(equipment_id: str, scheduled_date: str, maintenance_type: str,
                            description: str, technician: str, next_due_date: str,
                            status: str = "Scheduled") -> tuple[str | None, str | None]:
    equipment = data_loader.load_equipment()
    if equipment.empty or not (equipment["equipment_id"] == equipment_id).any():
        return None, f"Unknown equipment_id: {equipment_id}"

    maintenance_id = data_loader.next_id(config.MAINTENANCE_CSV, "maintenance_id", "M", width=4)
    data_loader.append_row(config.MAINTENANCE_CSV, {
        "maintenance_id": maintenance_id,
        "equipment_id": equipment_id,
        "scheduled_date": scheduled_date,
        "completed_date": "",
        "maintenance_type": maintenance_type,
        "description": description,
        "status": status,
        "technician": technician,
        "next_due_date": next_due_date,
    })

    if status == "In Progress":
        data_loader.update_row(config.EQUIPMENT_CSV, "equipment_id", equipment_id,
                                {"maintenance_status": "Under Maintenance"})

    return maintenance_id, None


def complete_maintenance_record(maintenance_id: str, completed_date: str) -> bool:
    updated = data_loader.update_row(config.MAINTENANCE_CSV, "maintenance_id", maintenance_id, {
        "status": "Completed",
        "completed_date": completed_date,
    })
    if updated:
        records = data_loader.load_maintenance()
        record = records[records["maintenance_id"] == maintenance_id].iloc[0]
        data_loader.update_row(config.EQUIPMENT_CSV, "equipment_id", record["equipment_id"],
                                {"maintenance_status": "Up to date"})
    return updated


def _latest_record(equipment_id: str, maintenance: pd.DataFrame) -> pd.Series | None:
    records = maintenance[maintenance["equipment_id"] == equipment_id]
    if records.empty:
        return None
    return records.sort_values("next_due_date").iloc[-1]


def run_maintenance_monitoring(raise_alerts: bool = False) -> pd.DataFrame:
    """Computes availability + due/overdue/low-availability/repeated-alert flags
    for every equipment item. See run_condition_monitoring for why raise_alerts
    defaults to False."""
    equipment = data_loader.load_equipment()
    maintenance = data_loader.load_maintenance()
    today = date.today()

    if equipment.empty:
        return pd.DataFrame(columns=["equipment_id", "availability_pct", "flags"])

    results = []
    for _, eq in equipment.iterrows():
        equipment_id = eq["equipment_id"]
        flags = []
        availability = rules.calculate_availability(eq["operating_hours"], eq["downtime_hours"])

        record = _latest_record(equipment_id, maintenance)
        if record is not None and record["next_due_date"]:
            next_due = datetime.strptime(str(record["next_due_date"]), "%Y-%m-%d").date()
            if next_due < today:
                flags.append("Overdue")
            elif next_due <= today + timedelta(days=config.MAINTENANCE_DUE_SOON_DAYS):
                flags.append("Due Soon")
            if record["status"] == "In Progress":
                flags.append("Under Maintenance")

        if availability < config.AVAILABILITY_LOW_THRESHOLD_PCT:
            flags.append("Low Availability")

        if alerts.repeated_alert_count(equipment_id) > config.REPEATED_ALERT_THRESHOLD:
            flags.append("Repeated Alerts")

        if raise_alerts and ("Overdue" in flags or "Repeated Alerts" in flags):
            alerts.raise_alert("Equipment", equipment_id, "Maintenance", round(availability, 1), "Warning")

        results.append({
            "equipment_id": equipment_id,
            "equipment_type": eq["equipment_type"],
            "availability_pct": availability,
            "downtime_hours": eq["downtime_hours"],
            "flags": ", ".join(flags) if flags else "OK",
        })

    return pd.DataFrame(results)


def equipment_needing_attention(summary: pd.DataFrame | None = None) -> pd.DataFrame:
    """Convenience filter: equipment with any flag other than 'OK'."""
    if summary is None:
        summary = run_maintenance_monitoring()
    if summary.empty:
        return summary
    return summary[summary["flags"] != "OK"]
