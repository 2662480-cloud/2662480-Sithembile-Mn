"""
d) Equipment Database.

Condition classification and maintenance-status flagging live in
condition_monitoring.py and maintenance.py - this module only owns the
equipment record's own CRUD.
"""

import pandas as pd

from src import config, data_loader, rules

VALID_STATUS = {"OK", "Warning", "Fault"}


def add_or_update_equipment(equipment_id: str, equipment_type: str, manufacturer: str,
                             operating_hours: float, temperature: float, vibration: float,
                             fuel_consumption: float, brake_status: str, tyre_status: str,
                             engine_status: str, maintenance_status: str,
                             downtime_hours: float) -> tuple[bool, str | None]:
    if not equipment_id or not equipment_type:
        return False, "Equipment ID and type are required"
    if operating_hours < 0 or downtime_hours < 0:
        return False, "Operating hours and downtime cannot be negative"
    for label, status in (("Brake", brake_status), ("Tyre", tyre_status), ("Engine", engine_status)):
        if status not in VALID_STATUS:
            return False, f"{label} status must be one of {VALID_STATUS}"

    equipment = data_loader.load_equipment()
    row = {
        "equipment_id": equipment_id,
        "equipment_type": equipment_type,
        "manufacturer": manufacturer,
        "operating_hours": operating_hours,
        "temperature": temperature,
        "vibration": vibration,
        "fuel_consumption": fuel_consumption,
        "brake_status": brake_status,
        "tyre_status": tyre_status,
        "engine_status": engine_status,
        "maintenance_status": maintenance_status,
        "downtime_hours": downtime_hours,
    }

    if not equipment.empty and (equipment["equipment_id"] == equipment_id).any():
        data_loader.update_row(config.EQUIPMENT_CSV, "equipment_id", equipment_id, row)
    else:
        data_loader.append_row(config.EQUIPMENT_CSV, row)

    return True, None


def view_equipment(equipment_type: str | None = None,
                    maintenance_status: str | None = None) -> pd.DataFrame:
    equipment = data_loader.load_equipment()
    if equipment.empty:
        return equipment

    equipment = equipment.copy()
    equipment["availability_pct"] = equipment.apply(
        lambda r: rules.calculate_availability(r["operating_hours"], r["downtime_hours"]), axis=1
    )

    if equipment_type:
        equipment = equipment[equipment["equipment_type"] == equipment_type]
    if maintenance_status:
        equipment = equipment[equipment["maintenance_status"] == maintenance_status]

    return equipment


def get_equipment(equipment_id: str) -> pd.Series | None:
    equipment = data_loader.load_equipment()
    match = equipment[equipment["equipment_id"] == equipment_id]
    return match.iloc[0] if not match.empty else None
