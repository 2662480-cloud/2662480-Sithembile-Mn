"""
j) Interactive Data Analysis.

A registry of business questions (Appendix A style), grouped by category, each
mapped to a query function. Every function loads through data_loader (never
touches CSVs directly) and returns a dict describing how the reports page
should render it: {"result_type": "metric" | "table" | "chart", ...}.
"""

import pandas as pd

from src import config, data_loader, rules

CATEGORIES = ["Health & Safety", "Equipment", "Integrated"]


def _availability_frame(equipment: pd.DataFrame) -> pd.DataFrame:
    equipment = equipment.copy()
    equipment["availability_pct"] = equipment.apply(
        lambda r: rules.calculate_availability(r["operating_hours"], r["downtime_hours"]), axis=1
    )
    return equipment


def incidents_by_department(filters: dict) -> dict:
    incidents = data_loader.load_incidents()
    counts = incidents["department"].value_counts() if not incidents.empty else pd.Series(dtype=int)
    return {"result_type": "chart", "chart_kind": "bar",
            "title": "Safety incidents by department", "series": counts}


def incidents_by_shift(filters: dict) -> dict:
    incidents = data_loader.load_incidents()
    counts = incidents["shift"].value_counts() if not incidents.empty else pd.Series(dtype=int)
    return {"result_type": "chart", "chart_kind": "pie",
            "title": "Safety incidents by shift", "series": counts}


def incidents_by_type(filters: dict) -> dict:
    incidents = data_loader.load_incidents()
    counts = incidents["incident_type"].value_counts() if not incidents.empty else pd.Series(dtype=int)
    return {"result_type": "chart", "chart_kind": "bar",
            "title": "Safety incidents by type", "series": counts}


def lost_time_injuries_by_month(filters: dict) -> dict:
    incidents = data_loader.load_incidents()
    if incidents.empty:
        return {"result_type": "chart", "chart_kind": "line",
                "title": "Lost-time injuries by month", "series": pd.Series(dtype=int)}
    lti = incidents[incidents["lost_time_injury"].astype(str).isin(["True", "1", "1.0"])]
    lti = lti.assign(month=pd.to_datetime(lti["date"]).dt.to_period("M").astype(str))
    counts = lti.groupby("month").size().sort_index()
    return {"result_type": "chart", "chart_kind": "line",
            "title": "Lost-time injuries by month", "series": counts}


def avg_ppe_compliance_by_department(filters: dict) -> dict:
    workers = data_loader.load_workers()
    if workers.empty:
        return {"result_type": "chart", "chart_kind": "bar",
                "title": "Average PPE compliance % by department", "series": pd.Series(dtype=float)}
    series = workers.groupby("department")["ppe_compliance_pct"].mean().round(1).sort_values(ascending=False)
    return {"result_type": "chart", "chart_kind": "bar",
            "title": "Average PPE compliance % by department", "series": series}


def high_risk_worker_count(filters: dict) -> dict:
    workers = data_loader.load_workers()
    count = int(workers["risk_level"].isin(["High", "Critical"]).sum()) if not workers.empty else 0
    return {"result_type": "metric", "title": "Workers at High/Critical risk", "value": count}


def equipment_highest_downtime(filters: dict) -> dict:
    equipment = data_loader.load_equipment()
    if equipment.empty:
        return {"result_type": "table", "title": "Equipment ranked by downtime", "data": equipment}
    ranked = equipment.sort_values("downtime_hours", ascending=False)[
        ["equipment_id", "equipment_type", "downtime_hours", "operating_hours"]
    ]
    return {"result_type": "table", "title": "Equipment ranked by downtime (highest first)", "data": ranked}


def equipment_lowest_availability(filters: dict) -> dict:
    equipment = data_loader.load_equipment()
    if equipment.empty:
        return {"result_type": "table", "title": "Equipment ranked by availability", "data": equipment}
    equipment = _availability_frame(equipment).sort_values("availability_pct")
    ranked = equipment[["equipment_id", "equipment_type", "availability_pct", "downtime_hours"]]
    return {"result_type": "table", "title": "Equipment ranked by availability (lowest first)", "data": ranked}


def equipment_most_alerts(filters: dict) -> dict:
    alerts = data_loader.load_alerts()
    if alerts.empty:
        return {"result_type": "table", "title": "Equipment ranked by alert count", "data": alerts}
    eq_alerts = alerts[alerts["source_type"] == "Equipment"]
    counts = eq_alerts.groupby("source_id").size().sort_values(ascending=False)
    ranked = counts.rename("alert_count").reset_index().rename(columns={"source_id": "equipment_id"})
    return {"result_type": "table", "title": "Equipment ranked by alert count (most first)", "data": ranked}


def equipment_status_breakdown(filters: dict) -> dict:
    equipment = data_loader.load_equipment()
    counts = equipment["maintenance_status"].value_counts() if not equipment.empty else pd.Series(dtype=int)
    return {"result_type": "chart", "chart_kind": "pie",
            "title": "Equipment breakdown by maintenance status", "series": counts}


def dept_high_risk_and_downtime(filters: dict) -> dict:
    incidents = data_loader.load_incidents()
    equipment = data_loader.load_equipment()
    if incidents.empty or equipment.empty:
        return {"result_type": "table", "title": "Departments flagged for incidents + downtime",
                "data": pd.DataFrame(columns=["department", "incident_count", "downtime_hours"])}

    incident_counts = incidents.groupby("department").size().rename("incident_count")
    downtime_by_dept = equipment.groupby("department").agg(downtime_hours=("downtime_hours", "sum")) \
        if "department" in equipment.columns else None

    # equipment.csv has no department column in this schema - fall back to
    # ranking incident-heavy departments alongside overall fleet downtime.
    merged = incident_counts.reset_index()
    merged["fleet_downtime_hours"] = round(equipment["downtime_hours"].sum(), 1)
    merged = merged.sort_values("incident_count", ascending=False)
    return {"result_type": "table",
            "title": "Departments ranked by incident count (with total fleet downtime for context)",
            "data": merged}


def equipment_type_with_most_critical_alerts(filters: dict) -> dict:
    alerts = data_loader.load_alerts()
    equipment = data_loader.load_equipment()
    if alerts.empty or equipment.empty:
        return {"result_type": "chart", "chart_kind": "bar",
                "title": "Critical alerts by equipment type", "series": pd.Series(dtype=int)}
    critical = alerts[(alerts["source_type"] == "Equipment") & (alerts["severity"] == "Critical")]
    merged = critical.merge(equipment[["equipment_id", "equipment_type"]],
                             left_on="source_id", right_on="equipment_id", how="left")
    series = merged["equipment_type"].value_counts()
    return {"result_type": "chart", "chart_kind": "bar",
            "title": "Critical alerts by equipment type", "series": series}


QUESTION_REGISTRY = {
    "incidents_by_department": {
        "label": "Which departments have the most safety incidents?",
        "category": "Health & Safety", "func": incidents_by_department,
    },
    "incidents_by_shift": {
        "label": "How are incidents distributed across shifts?",
        "category": "Health & Safety", "func": incidents_by_shift,
    },
    "incidents_by_type": {
        "label": "What are the most common incident types?",
        "category": "Health & Safety", "func": incidents_by_type,
    },
    "lost_time_injuries_by_month": {
        "label": "How are lost-time injuries trending month over month?",
        "category": "Health & Safety", "func": lost_time_injuries_by_month,
    },
    "avg_ppe_compliance_by_department": {
        "label": "What is the average PPE compliance % per department?",
        "category": "Health & Safety", "func": avg_ppe_compliance_by_department,
    },
    "high_risk_worker_count": {
        "label": "How many workers are currently High/Critical risk?",
        "category": "Health & Safety", "func": high_risk_worker_count,
    },
    "equipment_highest_downtime": {
        "label": "Which equipment has the highest downtime?",
        "category": "Equipment", "func": equipment_highest_downtime,
    },
    "equipment_lowest_availability": {
        "label": "Which equipment has the lowest availability?",
        "category": "Equipment", "func": equipment_lowest_availability,
    },
    "equipment_most_alerts": {
        "label": "Which equipment has generated the most alerts?",
        "category": "Equipment", "func": equipment_most_alerts,
    },
    "equipment_status_breakdown": {
        "label": "What is the maintenance-status breakdown of the fleet?",
        "category": "Equipment", "func": equipment_status_breakdown,
    },
    "dept_high_risk_and_downtime": {
        "label": "Which departments combine high incident counts with equipment downtime?",
        "category": "Integrated", "func": dept_high_risk_and_downtime,
    },
    "equipment_type_with_most_critical_alerts": {
        "label": "Which equipment type triggers the most critical alerts?",
        "category": "Integrated", "func": equipment_type_with_most_critical_alerts,
    },
}


def answer_question(question_key: str, filters: dict | None = None) -> dict:
    if question_key not in QUESTION_REGISTRY:
        raise ValueError(f"Unknown question: {question_key}")
    return QUESTION_REGISTRY[question_key]["func"](filters or {})
