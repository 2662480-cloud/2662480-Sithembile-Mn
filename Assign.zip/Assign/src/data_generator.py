"""
Synthetic dataset generator.

Populates data/*.csv with a realistic (but fictional) prototype dataset so
the application, dashboard and analytics have something to run against.
Run standalone:

    python -m src.data_generator

Re-running overwrites all data/*.csv with a fresh (but reproducible, fixed
seed) dataset - alerts.csv is derived from the SAME rule functions used by
the live application (src/rules.py), not generated independently, so the
demo alerts are consistent with what the app would compute on this data.
"""

import hashlib
import random
from datetime import date, datetime, timedelta

import pandas as pd

from src import config, data_loader, rules

random.seed(42)

TODAY = date.today()

FIRST_NAMES = [
    "Thabo", "Sipho", "Lerato", "Nomvula", "Karabo", "Tshepo", "Zanele", "Bongani",
    "Naledi", "Mpho", "Kagiso", "Palesa", "Sibusiso", "Ayanda", "Katlego", "Refilwe",
    "Lindiwe", "Themba", "Boitumelo", "Vusi", "Nomsa", "Andile", "Lesego", "Mandla",
]
LAST_NAMES = [
    "Mokoena", "Nkosi", "Dlamini", "Sithole", "Molefe", "Khumalo", "Zulu", "Mahlangu",
    "Radebe", "Ndlovu", "Mabaso", "Tshabalala", "Mthembu", "Sibanda", "Mnisi", "Maluleke",
]

JOB_ROLES = [
    "Machine Operator", "Drill Operator", "Blaster", "Rigger", "Artisan",
    "Team Leader", "Surveyor", "General Worker", "Winch Operator", "Fitter",
]

TRAINING_STATUS = ["Current", "Current", "Current", "Pending", "Expired"]

INCIDENT_TYPES = [
    "Fall", "Equipment Contact", "Fire", "Chemical Exposure", "Slip/Trip",
    "Struck by Object", "Vehicle Collision", "Electrical", "Fall of Ground",
]
INCIDENT_CAUSES = [
    "Unsafe act", "Unsafe condition", "Equipment failure", "Procedure not followed",
    "Poor housekeeping", "Fatigue", "Inadequate PPE", "Communication failure",
]
LOCATIONS = ["Shaft 1", "Shaft 3", "Pit A", "Pit B", "Plant 2", "Conveyor Belt 4",
             "Workshop", "Stockyard", "Haul Road 2"]

EQUIPMENT_PREFIX = {
    "Haul Truck": "TRK", "Loader": "LDR", "Excavator": "EXC", "Drilling Machine": "DRL",
    "Bulldozer": "BDZ", "Scraper Winch": "SCR", "Crusher": "CRS", "Conveyor": "CNV",
}
MANUFACTURERS = ["Caterpillar", "Komatsu", "Sandvik", "Epiroc", "Liebherr", "Volvo"]
STATUS_OK_WEIGHTED = ["OK", "OK", "OK", "OK", "Warning", "Fault"]

MAINTENANCE_TYPES = ["Preventive", "Corrective", "Inspection"]
TECHNICIANS = ["J. van der Merwe", "T. Phala", "K. Sithole", "M. Nkosi", "R. Botha"]


def _hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def _random_name() -> str:
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"


def generate_users() -> pd.DataFrame:
    rows = []
    demo_users = [
        ("admin", "Site Administrator", "Administrator"),
        ("safety1", "Palesa Mokoena", "Safety Officer"),
        ("mining1", "Tshepo Radebe", "Mining Engineer"),
        ("maint1", "Sibusiso Khumalo", "Maintenance Engineer"),
        ("manager1", "Naledi Dlamini", "Manager"),
    ]
    for i, (username, full_name, role) in enumerate(demo_users, start=1):
        rows.append({
            "user_id": f"U{i:03d}",
            "username": username,
            # Demo/prototype password for every account: "password123"
            "password_hash": _hash_password("password123"),
            "full_name": full_name,
            "role": role,
            "active": True,
        })
    return pd.DataFrame(rows)


def generate_workers(n: int = 150) -> pd.DataFrame:
    rows = []
    for i in range(1, n + 1):
        ppe = round(random.triangular(40, 100, 92), 1)
        fatigue = random.choices([1, 2, 3, 4, 5], weights=[15, 25, 30, 20, 10])[0]
        near_misses = random.choices([0, 1, 2, 3, 4, 5], weights=[40, 25, 15, 10, 6, 4])[0]
        previous_incidents = random.choices([0, 1, 2, 3], weights=[60, 25, 10, 5])[0]

        risk_level = rules.evaluate_worker_risk(ppe, fatigue, near_misses, previous_incidents)

        rows.append({
            "worker_id": f"W{i:03d}",
            "name": _random_name(),
            "department": random.choice(config.DEPARTMENTS),
            "job_role": random.choice(JOB_ROLES),
            "shift": random.choice(config.SHIFTS),
            "ppe_compliance_pct": ppe,
            "safety_training_status": random.choice(TRAINING_STATUS),
            "fatigue_level": fatigue,
            "safety_observations": random.randint(0, 10),
            "near_misses": near_misses,
            "previous_incidents": previous_incidents,
            "risk_level": risk_level,
        })
    return pd.DataFrame(rows)


def generate_equipment(n: int = 40) -> pd.DataFrame:
    rows = []
    type_counters = {t: 0 for t in config.EQUIPMENT_TYPES}
    for _ in range(n):
        eq_type = random.choice(config.EQUIPMENT_TYPES)
        type_counters[eq_type] += 1
        prefix = EQUIPMENT_PREFIX[eq_type]
        equipment_id = f"{prefix}-{type_counters[eq_type]:03d}"

        temperature = round(random.triangular(45, 115, 65), 1)
        vibration = round(random.triangular(1, 10, 3.5), 1)
        operating_hours = round(random.uniform(200, 20000), 1)
        downtime_hours = round(operating_hours * random.uniform(0.02, 0.35), 1)

        rows.append({
            "equipment_id": equipment_id,
            "equipment_type": eq_type,
            "manufacturer": random.choice(MANUFACTURERS),
            "operating_hours": operating_hours,
            "temperature": temperature,
            "vibration": vibration,
            "fuel_consumption": round(random.uniform(15, 120), 1),
            "brake_status": random.choice(STATUS_OK_WEIGHTED),
            "tyre_status": random.choice(STATUS_OK_WEIGHTED),
            "engine_status": random.choice(STATUS_OK_WEIGHTED),
            "maintenance_status": "Up to date",  # refined after maintenance_records are generated
            "downtime_hours": downtime_hours,
        })
    return pd.DataFrame(rows)


def generate_maintenance_records(equipment_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    counter = 1
    for _, eq in equipment_df.iterrows():
        n_records = random.randint(1, 3)
        for _ in range(n_records):
            days_offset = random.randint(-60, 45)
            next_due_date = TODAY + timedelta(days=days_offset)
            scheduled_date = next_due_date - timedelta(days=random.randint(30, 90))

            if days_offset < 0:
                status = random.choice(["Overdue", "Completed"])
            elif days_offset <= config.MAINTENANCE_DUE_SOON_DAYS:
                status = "Due"
            else:
                status = random.choice(["Scheduled", "Completed"])

            completed_date = ""
            if status == "Completed":
                completed_date = str(scheduled_date + timedelta(days=random.randint(0, 5)))
            elif status not in ("Overdue", "Due", "Scheduled") and random.random() < 0.3:
                status = "In Progress"

            rows.append({
                "maintenance_id": f"M{counter:04d}",
                "equipment_id": eq["equipment_id"],
                "scheduled_date": str(scheduled_date),
                "completed_date": completed_date,
                "maintenance_type": random.choice(MAINTENANCE_TYPES),
                "description": f"{random.choice(MAINTENANCE_TYPES)} maintenance - routine check",
                "status": status,
                "technician": random.choice(TECHNICIANS),
                "next_due_date": str(next_due_date),
            })
            counter += 1
    return pd.DataFrame(rows)


def refine_equipment_maintenance_status(equipment_df: pd.DataFrame, maintenance_df: pd.DataFrame) -> pd.DataFrame:
    """Set each equipment's maintenance_status from its most recent maintenance record."""
    equipment_df = equipment_df.copy()
    for idx, eq in equipment_df.iterrows():
        eq_records = maintenance_df[maintenance_df["equipment_id"] == eq["equipment_id"]]
        if eq_records.empty:
            continue
        latest = eq_records.sort_values("next_due_date").iloc[-1]
        status_map = {
            "Overdue": "Overdue",
            "Due": "Due",
            "In Progress": "Under Maintenance",
            "Scheduled": "Up to date",
            "Completed": "Up to date",
        }
        equipment_df.at[idx, "maintenance_status"] = status_map.get(latest["status"], "Up to date")
    return equipment_df


def generate_incidents(workers_df: pd.DataFrame, n: int = 80) -> pd.DataFrame:
    rows = []
    for i in range(1, n + 1):
        worker = workers_df.sample(1).iloc[0]
        incident_date = TODAY - timedelta(days=random.randint(0, 365))
        severity = random.choices([1, 2, 3, 4, 5], weights=[35, 30, 20, 10, 5])[0]

        if severity <= 1:
            injury_status = "None"
        elif severity == 2:
            injury_status = "First Aid"
        elif severity <= 4:
            injury_status = "Medical Treatment"
        else:
            injury_status = "Lost Time"

        rows.append({
            "incident_id": f"INC{i:04d}",
            "worker_id": worker["worker_id"],
            "date": str(incident_date),
            "time": f"{random.randint(0, 23):02d}:{random.choice(['00', '15', '30', '45'])}",
            "shift": worker["shift"],
            "location": random.choice(LOCATIONS),
            "department": worker["department"],
            "incident_type": random.choice(INCIDENT_TYPES),
            "severity": severity,
            "injury_status": injury_status,
            "lost_time_injury": injury_status == "Lost Time",
            "cause": random.choice(INCIDENT_CAUSES),
            "corrective_action": "Reviewed with supervisor; corrective briefing issued",
            "incident_status": random.choices(
                ["Closed", "Under Investigation", "Open"], weights=[65, 20, 15]
            )[0],
        })
    return pd.DataFrame(rows)


def generate_risk_assessments(workers_df: pd.DataFrame, equipment_df: pd.DataFrame,
                               incidents_df: pd.DataFrame, users_df: pd.DataFrame,
                               n: int = 50) -> pd.DataFrame:
    rows = []
    id_pools = {
        "Worker": list(workers_df["worker_id"]),
        "Equipment": list(equipment_df["equipment_id"]),
        "Incident": list(incidents_df["incident_id"]),
        "Department": config.DEPARTMENTS,
    }
    assessors = list(users_df["user_id"])

    for i in range(1, n + 1):
        related_type = random.choice(list(id_pools.keys()))
        related_id = random.choice(id_pools[related_type])
        likelihood = random.randint(1, 5)
        consequence = random.randint(1, 5)
        score = rules.calculate_risk_score(likelihood, consequence)
        classification = rules.classify_risk(score)

        rows.append({
            "risk_id": f"R{i:04d}",
            "related_type": related_type,
            "related_id": related_id,
            "likelihood": likelihood,
            "consequence": consequence,
            "risk_score": score,
            "classification": classification,
            "assessment_date": str(TODAY - timedelta(days=random.randint(0, 180))),
            "assessed_by": random.choice(assessors),
        })
    return pd.DataFrame(rows)


def generate_alerts(workers_df: pd.DataFrame, equipment_df: pd.DataFrame,
                     maintenance_df: pd.DataFrame, risk_df: pd.DataFrame) -> pd.DataFrame:
    """Alerts are DERIVED by running the same rule functions the live app uses -
    not randomly invented - so this log is consistent with equipment/worker data."""
    rows = []
    counter = 1

    def add_alert(source_type, source_id, parameter, value, severity):
        nonlocal counter
        timestamp = datetime.combine(TODAY, datetime.min.time()) - timedelta(
            hours=random.randint(0, 24 * 30)
        )
        rows.append({
            "alert_id": f"A{counter:04d}",
            "timestamp": str(timestamp),
            "source_type": source_type,
            "source_id": source_id,
            "parameter": parameter,
            "value": value,
            "severity": severity,
            "message": rules.format_alert_message(source_id, parameter, value, severity),
            "acknowledged": random.random() < 0.4,
        })
        counter += 1

    # Equipment condition monitoring
    for _, eq in equipment_df.iterrows():
        temp_status = rules.classify_temperature(eq["temperature"])
        if temp_status != "Normal":
            add_alert("Equipment", eq["equipment_id"], "Temperature", eq["temperature"], temp_status)

        vib_status = rules.classify_vibration(eq["vibration"])
        if vib_status != "Normal":
            add_alert("Equipment", eq["equipment_id"], "Vibration", eq["vibration"], vib_status)

    # Maintenance monitoring: overdue equipment
    overdue_ids = maintenance_df.loc[maintenance_df["status"] == "Overdue", "equipment_id"].unique()
    for equipment_id in overdue_ids:
        add_alert("Equipment", equipment_id, "Maintenance", "Overdue", "Warning")

    # Worker safety monitoring: High/Critical risk workers
    at_risk = workers_df[workers_df["risk_level"].isin(["High", "Critical"])]
    for _, worker in at_risk.iterrows():
        add_alert("Worker", worker["worker_id"], "Risk Level", worker["risk_level"], worker["risk_level"])

    # Risk assessments: High/Critical classifications
    high_risk = risk_df[risk_df["classification"].isin(["High", "Critical"])]
    for _, risk in high_risk.iterrows():
        add_alert(risk["related_type"], risk["related_id"], "Risk Score",
                  risk["risk_score"], risk["classification"])

    return pd.DataFrame(rows)


def generate_all(verbose: bool = True) -> None:
    users_df = generate_users()
    workers_df = generate_workers()
    equipment_df = generate_equipment()
    maintenance_df = generate_maintenance_records(equipment_df)
    equipment_df = refine_equipment_maintenance_status(equipment_df, maintenance_df)
    incidents_df = generate_incidents(workers_df)
    risk_df = generate_risk_assessments(workers_df, equipment_df, incidents_df, users_df)
    alerts_df = generate_alerts(workers_df, equipment_df, maintenance_df, risk_df)

    data_loader.save_csv(config.USERS_CSV, users_df)
    data_loader.save_csv(config.WORKERS_CSV, workers_df)
    data_loader.save_csv(config.EQUIPMENT_CSV, equipment_df)
    data_loader.save_csv(config.MAINTENANCE_CSV, maintenance_df)
    data_loader.save_csv(config.INCIDENTS_CSV, incidents_df)
    data_loader.save_csv(config.RISK_CSV, risk_df)
    data_loader.save_csv(config.ALERTS_CSV, alerts_df)

    if verbose:
        print("Generated synthetic dataset:")
        print(f"  users.csv               {len(users_df):>4} rows")
        print(f"  workers.csv             {len(workers_df):>4} rows")
        print(f"  equipment.csv           {len(equipment_df):>4} rows")
        print(f"  maintenance_records.csv {len(maintenance_df):>4} rows")
        print(f"  safety_incidents.csv    {len(incidents_df):>4} rows")
        print(f"  risk_assessments.csv    {len(risk_df):>4} rows")
        print(f"  alerts.csv              {len(alerts_df):>4} rows")
        print(f"\nDemo login: any of admin/safety1/mining1/maint1/manager1, password: password123")


if __name__ == "__main__":
    generate_all()
