"""
a) Access Control (RBAC login).

Role -> permission mapping lives in config.ROLE_PERMISSIONS (Table 1 of the
brief), not per-user, so it is defined in exactly one place.
"""

import hashlib
from dataclasses import dataclass

from src import config, data_loader


@dataclass
class Session:
    user_id: str
    username: str
    full_name: str
    role: str
    permissions: set


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def login(username: str, password: str) -> tuple[Session | None, str | None]:
    """Returns (session, error). Exactly one of the two is None."""
    users = data_loader.load_users()
    match = users[users["username"] == username]

    if match.empty:
        return None, "Invalid username or password"

    record = match.iloc[0]
    if hash_password(password) != record["password_hash"]:
        return None, "Invalid username or password"

    if not bool(record["active"]):
        return None, "This account has been disabled"

    role = record["role"]
    permissions = config.ROLE_PERMISSIONS.get(role, set())

    session = Session(
        user_id=record["user_id"],
        username=record["username"],
        full_name=record["full_name"],
        role=role,
        permissions=permissions,
    )
    return session, None


def has_permission(session: Session | None, feature: str) -> bool:
    if session is None:
        return False
    return feature in session.permissions
