"""
b) Worker Health and Safety Monitoring.
"""

import pandas as pd

from src import alerts, config, data_loader, rules

VALID_TRAINING_STATUS = {"Current", "Pending", "Expired"}


def add_worker(name: str, department: str, job_role: str, shift: str,
                ppe_compliance_pct: float, safety_training_status: str,
                fatigue_level: int, safety_observations: int, near_misses: int,
                previous_incidents: int) -> tuple[str | None, str | None]:
    """Returns (worker_id, error). Exactly one of the two is None."""

    if not name or not department or not job_role:
        return None, "Name, department and job role are required"
    if not (0 <= ppe_compliance_pct <= 100):
        return None, "PPE compliance must be between 0 and 100"
    if not (1 <= fatigue_level <= 5):
        return None, "Fatigue level must be between 1 and 5"
    if safety_training_status not in VALID_TRAINING_STATUS:
        return None, f"Training status must be one of {VALID_TRAINING_STATUS}"
    if safety_observations < 0 or near_misses < 0 or previous_incidents < 0:
        return None, "Counts cannot be negative"

    worker_id = data_loader.next_id(config.WORKERS_CSV, "worker_id", "W")
    risk_level = rules.evaluate_worker_risk(
        ppe_compliance_pct, fatigue_level, near_misses, previous_incidents
    )

    data_loader.append_row(config.WORKERS_CSV, {
        "worker_id": worker_id,
        "name": name,
        "department": department,
        "job_role": job_role,
        "shift": shift,
        "ppe_compliance_pct": ppe_compliance_pct,
        "safety_training_status": safety_training_status,
        "fatigue_level": fatigue_level,
        "safety_observations": safety_observations,
        "near_misses": near_misses,
        "previous_incidents": previous_incidents,
        "risk_level": risk_level,
    })

    if risk_level in {"High", "Critical"}:
        alerts.raise_alert(
            source_type="Worker", source_id=worker_id,
            parameter="Risk Level", value=risk_level, severity=risk_level,
        )

    return worker_id, None


def view_workers(department: str | None = None, shift: str | None = None,
                  risk_level: str | None = None) -> pd.DataFrame:
    workers = data_loader.load_workers()
    if department and not workers.empty:
        workers = workers[workers["department"] == department]
    if shift and not workers.empty:
        workers = workers[workers["shift"] == shift]
    if risk_level and not workers.empty:
        workers = workers[workers["risk_level"] == risk_level]
    return workers


def unsafe_conditions_summary() -> dict:
    """Counts used by the dashboard and by supervisors scanning for problems."""
    workers = data_loader.load_workers()
    if workers.empty:
        return {"low_ppe_compliance": 0, "high_fatigue": 0, "high_risk_workers": 0}

    return {
        "low_ppe_compliance": int((workers["ppe_compliance_pct"] < 70).sum()),
        "high_fatigue": int((workers["fatigue_level"] >= 4).sum()),
        "high_risk_workers": int(workers["risk_level"].isin(["High", "Critical"]).sum()),
    }
