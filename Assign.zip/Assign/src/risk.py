"""
g) Risk Assessment.
"""

from datetime import date

import pandas as pd

from src import alerts, config, data_loader, rules

VALID_RELATED_TYPES = {"Worker", "Equipment", "Incident", "Department"}


def submit_risk_assessment(related_type: str, related_id: str, likelihood: int,
                            consequence: int, assessed_by: str) -> tuple[dict | None, str | None]:
    if related_type not in VALID_RELATED_TYPES:
        return None, f"related_type must be one of {VALID_RELATED_TYPES}"
    if not (1 <= likelihood <= 5) or not (1 <= consequence <= 5):
        return None, "Likelihood and Consequence must each be between 1 and 5"

    risk_score = rules.calculate_risk_score(likelihood, consequence)
    classification = rules.classify_risk(risk_score)
    risk_id = data_loader.next_id(config.RISK_CSV, "risk_id", "R", width=4)

    data_loader.append_row(config.RISK_CSV, {
        "risk_id": risk_id,
        "related_type": related_type,
        "related_id": related_id,
        "likelihood": likelihood,
        "consequence": consequence,
        "risk_score": risk_score,
        "classification": classification,
        "assessment_date": str(date.today()),
        "assessed_by": assessed_by,
    })

    if classification in {"High", "Critical"}:
        alerts.raise_alert(
            source_type=related_type, source_id=related_id,
            parameter="Risk Score", value=risk_score, severity=classification,
        )

    return {
        "risk_id": risk_id,
        "risk_score": risk_score,
        "classification": classification,
        "warning": classification in {"High", "Critical"},
    }, None


def list_risk_assessments(related_type: str | None = None,
                           classification: str | None = None) -> pd.DataFrame:
    risks = data_loader.load_risk_assessments()
    if risks.empty:
        return risks
    if related_type:
        risks = risks[risks["related_type"] == related_type]
    if classification:
        risks = risks[risks["classification"] == classification]
    return risks.sort_values("risk_score", ascending=False)
