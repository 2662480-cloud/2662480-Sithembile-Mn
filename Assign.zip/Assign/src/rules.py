"""
Pure business-rule functions - the direct implementation of pseudocode.md.

Kept dependency-free (no pandas here) so they are easy to unit test and to
reproduce on paper/whiteboard: each function takes plain values in and
returns plain values out. Both the data generator and the Streamlit app
import from here, so the rules are defined in exactly one place.
"""

from src import config


def calculate_availability(operating_hours: float, downtime_hours: float) -> float:
    """Availability = OperatingTime / (Downtime + OperatingTime) x 100."""
    total = operating_hours + downtime_hours
    if total <= 0:
        return 0.0
    return round((operating_hours / total) * 100, 1)


def classify_condition(value: float, warning_threshold: float, critical_threshold: float) -> str:
    """Classify a monitored parameter as Normal / Warning / Critical."""
    if value > critical_threshold:
        return "Critical"
    if value >= warning_threshold:
        return "Warning"
    return "Normal"


def classify_temperature(temperature_c: float) -> str:
    return classify_condition(temperature_c, config.TEMP_WARNING_C, config.TEMP_CRITICAL_C)


def classify_vibration(vibration_mms: float) -> str:
    return classify_condition(vibration_mms, config.VIBRATION_WARNING_MMS, config.VIBRATION_CRITICAL_MMS)


def worst_status(*statuses: str) -> str:
    """Combine several Normal/Warning/Critical statuses into one overall status."""
    order = {"Normal": 0, "Warning": 1, "Critical": 2}
    return max(statuses, key=lambda s: order.get(s, 0))


def build_condition_message(equipment_id: str, parameter: str, value: float, status: str) -> str | None:
    """Human-readable message per the brief's Figure 1 wording. None if Normal."""
    if status == "Normal":
        return None
    if status == "Critical":
        return (f"CRITICAL: Equipment {parameter.lower()} exceeds predefined threshold. "
                f"Inspection required.")
    return f"WARNING: Equipment {parameter.lower()} approaching predefined threshold."


def calculate_risk_score(likelihood: int, consequence: int) -> int:
    if not (1 <= likelihood <= 5) or not (1 <= consequence <= 5):
        raise ValueError("Likelihood and Consequence must each be between 1 and 5")
    return likelihood * consequence


def classify_risk(risk_score: int) -> str:
    for low, high, label in config.RISK_BANDS:
        if low <= risk_score <= high:
            return label
    raise ValueError(f"Risk score {risk_score} out of expected 1-25 range")


def evaluate_worker_risk(ppe_compliance_pct: float, fatigue_level: int,
                          near_misses: int, previous_incidents: int) -> str:
    """
    Composite worker risk indicator (not specified numerically in the brief -
    a simple additive scoring rule used to flag workers needing attention).
    """
    score = 0
    if ppe_compliance_pct < 70:
        score += 2
    if fatigue_level >= 4:
        score += 2
    if near_misses >= 3:
        score += 1
    if previous_incidents >= 2:
        score += 2

    if score >= 5:
        return "Critical"
    if score >= 3:
        return "High"
    if score >= 1:
        return "Medium"
    return "Low"


def format_alert_message(source_id: str, parameter: str, value, severity: str) -> str:
    """Formats an alert exactly per Figure 1 in the brief."""
    return (
        "=====================================================\n"
        "MINING MONITORING ALERT\n"
        "=====================================================\n"
        f"[{severity.upper()}]\n"
        f"Equipment/Source ID: {source_id}\n"
        f"Parameter: {parameter}\n"
        f"Value: {value}\n"
        f"Status: Above {severity} Threshold\n"
        "Recommended Action:\n"
        " Inspect equipment and initiate appropriate\n"
        " maintenance/safety procedures.\n"
        "====================================================="
    )
