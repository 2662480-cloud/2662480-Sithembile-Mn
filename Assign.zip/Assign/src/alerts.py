"""
h) Alerts and Notifications.

Every other monitoring function (worker safety, condition monitoring,
maintenance monitoring, risk assessment) calls raise_alert() instead of
writing to alerts.csv directly - this is the single place alert rows are
created, so the format and side effects stay consistent everywhere.
"""

from datetime import datetime

import pandas as pd

from src import config, data_loader, rules


def raise_alert(source_type: str, source_id: str, parameter: str, value, severity: str) -> str:
    alert_id = data_loader.next_id(config.ALERTS_CSV, "alert_id", "A", width=4)
    message = rules.format_alert_message(source_id, parameter, value, severity)

    data_loader.append_row(config.ALERTS_CSV, {
        "alert_id": alert_id,
        "timestamp": str(datetime.now()),
        "source_type": source_type,
        "source_id": source_id,
        "parameter": parameter,
        "value": value,
        "severity": severity,
        "message": message,
        "acknowledged": False,
    })
    return alert_id


def acknowledge_alert(alert_id: str) -> bool:
    return data_loader.update_row(config.ALERTS_CSV, "alert_id", alert_id, {"acknowledged": True})


def list_alerts(active_only: bool = False, severity: str | None = None,
                 source_type: str | None = None) -> pd.DataFrame:
    alerts = data_loader.load_alerts()
    if active_only and not alerts.empty:
        alerts = alerts[alerts["acknowledged"] == False]  # noqa: E712
    if severity and not alerts.empty:
        alerts = alerts[alerts["severity"] == severity]
    if source_type and not alerts.empty:
        alerts = alerts[alerts["source_type"] == source_type]
    return alerts.sort_values("timestamp", ascending=False) if not alerts.empty else alerts


def count_active_alerts() -> int:
    return len(list_alerts(active_only=True))


def count_critical_alerts(active_only: bool = True) -> int:
    return len(list_alerts(active_only=active_only, severity="Critical"))


def repeated_alert_count(source_id: str) -> int:
    """How many alerts a given equipment/worker id has generated in total -
    used by maintenance monitoring to flag 'Repeated Alerts' equipment."""
    alerts = data_loader.load_alerts()
    if alerts.empty:
        return 0
    return int((alerts["source_id"] == source_id).sum())
