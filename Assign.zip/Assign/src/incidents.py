"""
c) Safety Incident Database.
"""

import pandas as pd

from src import alerts, config, data_loader

VALID_STATUS = {"Open", "Under Investigation", "Closed"}


def add_incident(worker_id: str, date: str, time: str, shift: str, location: str,
                  department: str, incident_type: str, severity: int, injury_status: str,
                  lost_time_injury: bool, cause: str, corrective_action: str,
                  incident_status: str = "Open") -> tuple[str | None, str | None]:
    if not (1 <= severity <= 5):
        return None, "Severity must be between 1 and 5"
    if incident_status not in VALID_STATUS:
        return None, f"Incident status must be one of {VALID_STATUS}"
    if not location or not department or not incident_type:
        return None, "Location, department and incident type are required"

    incident_id = data_loader.next_id(config.INCIDENTS_CSV, "incident_id", "INC", width=4)

    data_loader.append_row(config.INCIDENTS_CSV, {
        "incident_id": incident_id,
        "worker_id": worker_id,
        "date": date,
        "time": time,
        "shift": shift,
        "location": location,
        "department": department,
        "incident_type": incident_type,
        "severity": severity,
        "injury_status": injury_status,
        "lost_time_injury": lost_time_injury,
        "cause": cause,
        "corrective_action": corrective_action,
        "incident_status": incident_status,
    })

    if severity >= 4:
        alerts.raise_alert(
            source_type="Incident", source_id=incident_id,
            parameter="Severity", value=severity, severity="Critical",
        )

    return incident_id, None


def search_incidents(search_text: str | None = None, department: str | None = None,
                      shift: str | None = None, incident_type: str | None = None,
                      status: str | None = None, date_from: str | None = None,
                      date_to: str | None = None) -> pd.DataFrame:
    incidents = data_loader.load_incidents()
    if incidents.empty:
        return incidents

    if search_text:
        text = search_text.lower()
        mask = (
            incidents["location"].str.lower().str.contains(text, na=False)
            | incidents["cause"].str.lower().str.contains(text, na=False)
        )
        incidents = incidents[mask]
    if department:
        incidents = incidents[incidents["department"] == department]
    if shift:
        incidents = incidents[incidents["shift"] == shift]
    if incident_type:
        incidents = incidents[incidents["incident_type"] == incident_type]
    if status:
        incidents = incidents[incidents["incident_status"] == status]
    if date_from:
        incidents = incidents[incidents["date"] >= date_from]
    if date_to:
        incidents = incidents[incidents["date"] <= date_to]

    return incidents


def analyse_incident_trends(incidents: pd.DataFrame | None = None) -> dict:
    if incidents is None:
        incidents = data_loader.load_incidents()
    if incidents.empty:
        return {
            "by_department": pd.Series(dtype=int),
            "by_shift": pd.Series(dtype=int),
            "by_type": pd.Series(dtype=int),
            "high_critical_count": 0,
        }

    return {
        "by_department": incidents["department"].value_counts(),
        "by_shift": incidents["shift"].value_counts(),
        "by_type": incidents["incident_type"].value_counts(),
        "high_critical_count": int((incidents["severity"] >= 4).sum()),
    }
