"""
e) Equipment Condition Monitoring.
"""

import pandas as pd

from src import alerts, data_loader, rules


def evaluate_equipment_condition(equipment_id: str, temperature: float, vibration: float) -> dict:
    """Pure evaluation - no side effects. Used for a single on-demand check."""
    temp_status = rules.classify_temperature(temperature)
    vib_status = rules.classify_vibration(vibration)
    overall_status = rules.worst_status(temp_status, vib_status)

    messages = []
    temp_message = rules.build_condition_message(equipment_id, "Temperature", temperature, temp_status)
    if temp_message:
        messages.append(temp_message)
    vib_message = rules.build_condition_message(equipment_id, "Vibration", vibration, vib_status)
    if vib_message:
        messages.append(vib_message)

    return {
        "equipment_id": equipment_id,
        "temperature": temperature,
        "temperature_status": temp_status,
        "vibration": vibration,
        "vibration_status": vib_status,
        "overall_status": overall_status,
        "messages": messages,
    }


def run_condition_monitoring(equipment: pd.DataFrame | None = None,
                              raise_alerts: bool = False) -> pd.DataFrame:
    """Evaluate every equipment record and (optionally) log alerts for anything
    not Normal. Returns a summary DataFrame for display.

    raise_alerts defaults to False so simply viewing the dashboard/condition
    page does not spam alerts.csv with duplicates on every refresh - the UI
    should call this with raise_alerts=True only from an explicit
    'Run monitoring check' action."""
    if equipment is None:
        equipment = data_loader.load_equipment()
    if equipment.empty:
        return pd.DataFrame(columns=[
            "equipment_id", "temperature", "temperature_status",
            "vibration", "vibration_status", "overall_status",
        ])

    results = []
    for _, eq in equipment.iterrows():
        result = evaluate_equipment_condition(eq["equipment_id"], eq["temperature"], eq["vibration"])

        if raise_alerts:
            if result["temperature_status"] != "Normal":
                alerts.raise_alert("Equipment", eq["equipment_id"], "Temperature",
                                     eq["temperature"], result["temperature_status"])
            if result["vibration_status"] != "Normal":
                alerts.raise_alert("Equipment", eq["equipment_id"], "Vibration",
                                     eq["vibration"], result["vibration_status"])

        results.append({k: v for k, v in result.items() if k != "messages"})

    return pd.DataFrame(results)
