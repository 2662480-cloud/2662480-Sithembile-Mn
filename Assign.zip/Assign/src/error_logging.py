"""
Centralised error logging for the Streamlit app.

Every page render function is wrapped with @log_errors so an exception in one
page (a bad CSV row, a missing column, etc.) is written to logs/app.log with
a full traceback instead of crashing the whole app for every other page.
"""

import functools
import logging
import traceback
from pathlib import Path

from src import config

LOGGER_NAME = "mining_hse_app"
LOG_DIR_NAME = "logs"
LOG_FILE_NAME = "app.log"


def _log_path() -> Path:
    return config.BASE_DIR / LOG_DIR_NAME / LOG_FILE_NAME


def get_logger() -> logging.Logger:
    """Return the app logger, (re)pointed at the current config.BASE_DIR.

    Recomputes the target path on every call - cheap, and lets tests redirect
    config.BASE_DIR to a tmp directory without leaking a stale file handle
    from an earlier test.
    """
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(logging.INFO)

    path = _log_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    already_targets_path = any(
        isinstance(h, logging.FileHandler) and h.baseFilename == str(path)
        for h in logger.handlers
    )
    if not already_targets_path:
        for handler in list(logger.handlers):
            logger.removeHandler(handler)
        file_handler = logging.FileHandler(path, encoding="utf-8")
        file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        logger.addHandler(file_handler)

    return logger


def log_errors(page_name: str):
    """Decorator for a page's render() function: catch any exception, log it
    with a traceback, show the user a friendly message, and swallow it so the
    rest of the app keeps working."""

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as exc:
                get_logger().error(
                    "Error in page '%s': %s\n%s", page_name, exc, traceback.format_exc()
                )
                import streamlit as st
                st.error(f"Something went wrong loading '{page_name}'. The error has been logged.")
                return None
        return wrapper

    return decorator
