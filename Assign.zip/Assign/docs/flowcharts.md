# Flowcharts — Mining Health, Safety and Equipment Monitoring Application

One flowchart per required function (Section 3, a–j) plus the overall system flow.
Rendered with Mermaid (renders natively on GitHub).

## 0. Overall System Flow

```mermaid
flowchart TD
    Start([Start]) --> Login[Display Login Screen]
    Login --> Auth{Credentials valid?}
    Auth -- No --> Err[Show error message] --> Login
    Auth -- Yes --> Role[Look up user role]
    Role --> Menu[Render menu filtered by ROLE_PERMISSIONS]
    Menu --> Choice{User selects function}
    Choice -- Dashboard --> F_i[i. Dashboard]
    Choice -- Worker Safety --> F_b[b. Worker Safety Monitoring]
    Choice -- Incidents --> F_c[c. Safety Incident DB]
    Choice -- Equipment --> F_d[d. Equipment DB]
    Choice -- Condition Monitoring --> F_e[e. Equipment Condition Monitoring]
    Choice -- Maintenance --> F_f[f. Maintenance Monitoring]
    Choice -- Risk Assessment --> F_g[g. Risk Assessment]
    Choice -- Analysis --> F_j[j. Interactive Data Analysis]
    F_i --> Menu
    F_b --> Menu
    F_c --> Menu
    F_d --> Menu
    F_e --> Menu
    F_f --> Menu
    F_g --> Menu
    F_j --> Menu
    Menu -- Logout --> End([End])
```

## a) Access Control (RBAC Login)

```mermaid
flowchart TD
    A([Start]) --> B[User enters username & password]
    B --> C{User exists in users.csv?}
    C -- No --> D[Show 'Invalid credentials'] --> B
    C -- Yes --> E{Password hash matches?}
    E -- No --> D
    E -- Yes --> F{Account active?}
    F -- No --> G[Show 'Account disabled'] --> B
    F -- Yes --> H[Fetch role from user record]
    H --> I[Load permission set for role from ROLE_PERMISSIONS table]
    I --> J[Store role + permissions in session state]
    J --> K[Redirect to Dashboard with role-filtered menu]
    K --> L([End])
```

## b) Worker Health & Safety Monitoring

```mermaid
flowchart TD
    A([Start]) --> B{Action?}
    B -- Add Worker Record --> C[Capture Worker ID, Dept, Role, Shift,\nPPE compliance, Training status,\nFatigue level, Observations, Near misses,\nPrevious incidents]
    C --> D[Validate inputs: required fields, numeric ranges]
    D --> E{Valid?}
    E -- No --> F[Show validation error] --> C
    E -- Yes --> G[Compute worker risk indicators:\nlow PPE %, high fatigue, repeated near-misses]
    G --> H{Any indicator breaches threshold?}
    H -- Yes --> I[Set risk_level = High/Critical\nGenerate safety warning] --> J[Save record to workers.csv]
    H -- No --> K[Set risk_level = Low/Medium] --> J
    J --> L([Return to menu])
    B -- View/Filter Workers --> M[Load workers.csv into DataFrame]
    M --> N[Apply filters: department, shift, risk level]
    N --> O[Display table + highlight unsafe conditions]
    O --> L
```

## c) Safety Incident Database

```mermaid
flowchart TD
    A([Start]) --> B{Action?}
    B -- Add Incident --> C[Capture Incident ID, Date, Time, Shift,\nLocation, Dept, Type, Severity,\nInjury status, LTI flag, Cause,\nCorrective action, Status]
    C --> D{Required fields valid?}
    D -- No --> E[Show validation error] --> C
    D -- Yes --> F[Append record to safety_incidents.csv]
    F --> G{Severity high/critical?}
    G -- Yes --> H[Trigger Critical Incident Alert]
    G -- No --> I([Return to menu])
    H --> I
    B -- View/Search/Filter --> J[Load safety_incidents.csv]
    J --> K[Apply search text / filters:\ndept, shift, type, date range, status]
    K --> L[Display filtered table]
    L --> I
    B -- Analyse Trends --> M[Group by dept/shift/type/date]
    M --> N[Compute counts, percentages]
    N --> O[Render charts: incidents by dept, by shift, over time]
    O --> I
```

## d) Equipment Database

```mermaid
flowchart TD
    A([Start]) --> B{Action?}
    B -- Add/Update Equipment --> C[Capture Equipment ID, Type, Manufacturer,\nOperating hours, Temperature, Vibration,\nFuel, Brake/Tyre/Engine status,\nMaintenance status, Downtime]
    C --> D{Valid input?}
    D -- No --> E[Show validation error] --> C
    D -- Yes --> F[Save/update record in equipment.csv]
    F --> G([Return to menu])
    B -- View Equipment --> H[Load equipment.csv]
    H --> I[Filter by type / status]
    I --> J[Display table with derived availability %]
    J --> G
```

## e) Equipment Condition Monitoring

```mermaid
flowchart TD
    A([Start]) --> B[Select equipment record]
    B --> C[Read latest Temperature, Vibration]
    C --> D{Temperature > 100°C?}
    D -- Yes --> E[Status = CRITICAL: Temperature]
    D -- No --> F{Temperature >= 80°C?}
    F -- Yes --> G[Status = WARNING: Temperature]
    F -- No --> H[Status = NORMAL: Temperature]
    E --> I
    G --> I
    H --> I
    I{Vibration > 8 mm/s?}
    I -- Yes --> J[Status = CRITICAL: Vibration]
    I -- No --> K{Vibration >= 5 mm/s?}
    K -- Yes --> L[Status = WARNING: Vibration]
    K -- No --> M[Status = NORMAL: Vibration]
    J --> N[Compose message per Fig.1 template]
    L --> N
    M --> N
    N --> O{Overall status Warning/Critical?}
    O -- Yes --> P[Append entry to alerts.csv]
    O -- No --> Q([Display NORMAL status])
    P --> Q
```

## f) Equipment Maintenance Monitoring

```mermaid
flowchart TD
    A([Start]) --> B[Load equipment.csv + maintenance_records.csv]
    B --> C[For each equipment item]
    C --> D[Compute Availability =\nOperatingTime / (Downtime+OperatingTime) x 100]
    D --> E{next_due_date <= today?}
    E -- Yes, overdue --> F[Flag: Overdue]
    E -- No --> G{next_due_date within warning window?}
    G -- Yes --> H[Flag: Due Soon]
    G -- No --> I[Flag: Up to date]
    F --> J{Availability < threshold e.g. 80%?}
    H --> J
    I --> J
    J -- Yes --> K[Flag: Low Availability]
    J -- No --> L[No availability flag]
    K --> M{Repeated alerts on this equipment > N?}
    L --> M
    M -- Yes --> N[Flag: Repeated Alerts - priority maintenance]
    M -- No --> O[Compile maintenance status list]
    N --> O
    O --> P{Any Overdue / Repeated-Alert equipment?}
    P -- Yes --> Q[Append alert to alerts.csv]
    P -- No --> R([Display maintenance summary])
    Q --> R
```

## g) Risk Assessment

```mermaid
flowchart TD
    A([Start]) --> B[User selects subject:\nWorker / Equipment / Incident / Department]
    B --> C[User enters Likelihood 1-5]
    C --> D[User enters Consequence 1-5]
    D --> E[RiskScore = Likelihood x Consequence]
    E --> F{RiskScore 1-4?}
    F -- Yes --> G[Classification = Low]
    F -- No --> H{RiskScore 5-9?}
    H -- Yes --> I[Classification = Medium]
    H -- No --> J{RiskScore 10-16?}
    J -- Yes --> K[Classification = High]
    J -- No --> L[Classification = Critical]
    G --> M[Save to risk_assessments.csv]
    I --> M
    K --> M
    L --> M
    M --> N{Classification High or Critical?}
    N -- Yes --> O[Display warning banner\n+ append alert to alerts.csv]
    N -- No --> P([Display result])
    O --> P
```

## h) Alerts and Notifications

```mermaid
flowchart TD
    A([Start: triggered by b, e, f, or g]) --> B[Receive trigger event:\nsource_type, source_id, parameter, value, severity]
    B --> C[Format message using template:\nheader, severity tag, parameter, value,\nstatus, recommended action]
    C --> D[Append record to alerts.csv]
    D --> E{Severity = Critical?}
    E -- Yes --> F[Display prominent on-screen alert banner]
    E -- No --> G[Display standard warning notice]
    F --> H[Update dashboard active-alert counters]
    G --> H
    H --> I([End])
```

## i) Mining Monitoring Dashboard

```mermaid
flowchart TD
    A([Start]) --> B[Load workers.csv, safety_incidents.csv,\nequipment.csv, maintenance_records.csv, alerts.csv]
    B --> C[Compute KPIs:\nTotal workers, Total incidents, Near misses,\nHigh-risk observations, PPE compliance %]
    C --> D[Compute equipment KPIs:\nTotal equipment, Available, Under maintenance,\nAvg availability %, Active alerts, Critical alerts]
    D --> E[Render KPI cards]
    E --> F[Render summary charts:\nincidents trend, equipment status breakdown]
    F --> G([Display dashboard])
```

## j) Interactive Data Analysis

```mermaid
flowchart TD
    A([Start]) --> B[User selects a business question\nfrom categorized list\nHealth & Safety / Equipment / Integrated]
    B --> C[Map question to a query function]
    C --> D[Load relevant CSV(s) into DataFrame(s)]
    D --> E[Apply filter / groupby / aggregation\nspecific to the selected question]
    E --> F{Result type?}
    F -- Single value/stat --> G[Display metric]
    F -- Ranked list --> H[Display sorted table]
    F -- Trend/comparison --> I[Render chart: bar/line/pie]
    G --> J([End])
    H --> J
    I --> J
```
