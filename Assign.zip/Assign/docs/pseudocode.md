# Pseudocode — Mining Health, Safety and Equipment Monitoring Application

Structured (PDL-style) pseudocode for each required function (Section 3, a–j), matching
`data_model.md` and `flowcharts.md`. Field/table names match the CSV schema exactly so this
maps directly onto the Python implementation.

---

## a) Access Control (RBAC Login)

```
CONSTANT ROLE_PERMISSIONS = {
    "Administrator":         {dashboard, worker_data, incidents, equipment, maintenance, risk, reports, manage_users},
    "Safety Officer":        {dashboard, worker_data, incidents, risk, reports},
    "Mining Engineer":       {dashboard, worker_data, incidents, equipment, maintenance, risk, reports},
    "Maintenance Engineer":  {dashboard, equipment, maintenance, reports},
    "Manager":               {dashboard, worker_data, incidents, equipment, maintenance, risk, reports}
}

FUNCTION LOGIN(username, password):
    users = LOAD_CSV("users.csv")
    record = FIND_ROW(users, username == username)

    IF record IS NULL THEN
        RETURN ERROR("Invalid credentials")
    END IF

    IF HASH(password) != record.password_hash THEN
        RETURN ERROR("Invalid credentials")
    END IF

    IF record.active == FALSE THEN
        RETURN ERROR("Account disabled")
    END IF

    permissions = ROLE_PERMISSIONS[record.role]
    SESSION.user_id = record.user_id
    SESSION.role = record.role
    SESSION.permissions = permissions
    RETURN SUCCESS(record.role, permissions)
END FUNCTION

FUNCTION HAS_PERMISSION(feature_name):
    RETURN feature_name IN SESSION.permissions
END FUNCTION
```

---

## b) Worker Health and Safety Monitoring

```
FUNCTION ADD_WORKER(worker_id, department, job_role, shift, ppe_compliance_pct,
                     training_status, fatigue_level, observations, near_misses, previous_incidents):

    IF worker_id IS EMPTY OR ppe_compliance_pct NOT IN [0, 100] OR fatigue_level NOT IN [1, 5] THEN
        RETURN ERROR("Invalid input")
    END IF

    risk_level = EVALUATE_WORKER_RISK(ppe_compliance_pct, fatigue_level, near_misses, previous_incidents)

    APPEND_ROW("workers.csv", {worker_id, department, job_role, shift, ppe_compliance_pct,
                                training_status, fatigue_level, observations, near_misses,
                                previous_incidents, risk_level})

    IF risk_level IN {"High", "Critical"} THEN
        RAISE_ALERT(source_type="Worker", source_id=worker_id, parameter="Risk Level",
                     value=risk_level, severity=risk_level)
    END IF

    RETURN SUCCESS
END FUNCTION

FUNCTION EVALUATE_WORKER_RISK(ppe_compliance_pct, fatigue_level, near_misses, previous_incidents):
    score = 0
    IF ppe_compliance_pct < 70 THEN score = score + 2
    IF fatigue_level >= 4 THEN score = score + 2
    IF near_misses >= 3 THEN score = score + 1
    IF previous_incidents >= 2 THEN score = score + 2

    IF score >= 5 THEN RETURN "Critical"
    ELSE IF score >= 3 THEN RETURN "High"
    ELSE IF score >= 1 THEN RETURN "Medium"
    ELSE RETURN "Low"
    END IF
END FUNCTION

FUNCTION VIEW_WORKERS(filter_department = NULL, filter_shift = NULL, filter_risk = NULL):
    workers = LOAD_CSV("workers.csv")
    IF filter_department IS NOT NULL THEN
        workers = FILTER(workers, department == filter_department)
    END IF
    IF filter_shift IS NOT NULL THEN
        workers = FILTER(workers, shift == filter_shift)
    END IF
    IF filter_risk IS NOT NULL THEN
        workers = FILTER(workers, risk_level == filter_risk)
    END IF
    RETURN workers
END FUNCTION
```

---

## c) Safety Incident Database

```
FUNCTION ADD_INCIDENT(incident_id, worker_id, date, time, shift, location, department,
                       incident_type, severity, injury_status, lost_time_injury,
                       cause, corrective_action, incident_status):

    IF incident_id IS EMPTY OR severity NOT IN [1, 5] THEN
        RETURN ERROR("Invalid input")
    END IF

    APPEND_ROW("safety_incidents.csv", {incident_id, worker_id, date, time, shift, location,
                                         department, incident_type, severity, injury_status,
                                         lost_time_injury, cause, corrective_action, incident_status})

    IF severity >= 4 THEN
        RAISE_ALERT(source_type="Incident", source_id=incident_id, parameter="Severity",
                     value=severity, severity="Critical")
    END IF

    RETURN SUCCESS
END FUNCTION

FUNCTION SEARCH_INCIDENTS(search_text = NULL, department = NULL, shift = NULL,
                           incident_type = NULL, status = NULL, date_from = NULL, date_to = NULL):
    incidents = LOAD_CSV("safety_incidents.csv")

    IF search_text IS NOT NULL THEN
        incidents = FILTER(incidents, CONTAINS(location, search_text) OR CONTAINS(cause, search_text))
    END IF
    IF department IS NOT NULL THEN incidents = FILTER(incidents, department == department)
    IF shift IS NOT NULL THEN incidents = FILTER(incidents, shift == shift)
    IF incident_type IS NOT NULL THEN incidents = FILTER(incidents, incident_type == incident_type)
    IF status IS NOT NULL THEN incidents = FILTER(incidents, incident_status == status)
    IF date_from IS NOT NULL THEN incidents = FILTER(incidents, date >= date_from AND date <= date_to)

    RETURN incidents
END FUNCTION

FUNCTION ANALYSE_INCIDENT_TRENDS(incidents):
    by_department = GROUP_BY_COUNT(incidents, "department")
    by_shift      = GROUP_BY_COUNT(incidents, "shift")
    by_type       = GROUP_BY_COUNT(incidents, "incident_type")
    by_month      = GROUP_BY_COUNT(incidents, EXTRACT_MONTH(date))
    high_critical_count = COUNT(FILTER(incidents, severity >= 4))

    RETURN {by_department, by_shift, by_type, by_month, high_critical_count}
END FUNCTION
```

---

## d) Equipment Database

```
FUNCTION ADD_OR_UPDATE_EQUIPMENT(equipment_id, equipment_type, manufacturer, operating_hours,
                                  temperature, vibration, fuel_consumption, brake_status,
                                  tyre_status, engine_status, maintenance_status, downtime_hours):

    IF equipment_id IS EMPTY OR operating_hours < 0 OR downtime_hours < 0 THEN
        RETURN ERROR("Invalid input")
    END IF

    equipment = LOAD_CSV("equipment.csv")
    IF EXISTS(equipment, equipment_id == equipment_id) THEN
        UPDATE_ROW("equipment.csv", equipment_id, {equipment_type, manufacturer, operating_hours,
                                                     temperature, vibration, fuel_consumption,
                                                     brake_status, tyre_status, engine_status,
                                                     maintenance_status, downtime_hours})
    ELSE
        APPEND_ROW("equipment.csv", {equipment_id, equipment_type, manufacturer, operating_hours,
                                      temperature, vibration, fuel_consumption, brake_status,
                                      tyre_status, engine_status, maintenance_status, downtime_hours})
    END IF

    RETURN SUCCESS
END FUNCTION

FUNCTION VIEW_EQUIPMENT(filter_type = NULL, filter_status = NULL):
    equipment = LOAD_CSV("equipment.csv")
    FOR EACH row IN equipment:
        row.availability_pct = CALCULATE_AVAILABILITY(row.operating_hours, row.downtime_hours)
    END FOR

    IF filter_type IS NOT NULL THEN equipment = FILTER(equipment, equipment_type == filter_type)
    IF filter_status IS NOT NULL THEN equipment = FILTER(equipment, maintenance_status == filter_status)

    RETURN equipment
END FUNCTION
```

---

## e) Equipment Condition Monitoring

```
CONSTANT TEMP_WARNING = 80, TEMP_CRITICAL = 100
CONSTANT VIB_WARNING = 5, VIB_CRITICAL = 8

FUNCTION CHECK_CONDITION(equipment_id, temperature, vibration):
    temp_status = CLASSIFY(temperature, TEMP_WARNING, TEMP_CRITICAL)
    vib_status  = CLASSIFY(vibration, VIB_WARNING, VIB_CRITICAL)

    messages = []
    IF temp_status != "Normal" THEN
        messages.ADD(BUILD_ALERT_MESSAGE(equipment_id, "Temperature", temperature, temp_status))
    END IF
    IF vib_status != "Normal" THEN
        messages.ADD(BUILD_ALERT_MESSAGE(equipment_id, "Vibration", vibration, vib_status))
    END IF

    FOR EACH msg IN messages:
        RAISE_ALERT(source_type="Equipment", source_id=equipment_id, parameter=msg.parameter,
                     value=msg.value, severity=msg.status)
    END FOR

    overall_status = WORST_OF(temp_status, vib_status)
    RETURN {equipment_id, temp_status, vib_status, overall_status, messages}
END FUNCTION

FUNCTION CLASSIFY(value, warning_threshold, critical_threshold):
    IF value > critical_threshold THEN RETURN "Critical"
    ELSE IF value >= warning_threshold THEN RETURN "Warning"
    ELSE RETURN "Normal"
    END IF
END FUNCTION

FUNCTION BUILD_ALERT_MESSAGE(equipment_id, parameter, value, status):
    IF status == "Critical" THEN
        text = "CRITICAL: Equipment " + parameter + " exceeds predefined threshold. Inspection required."
    ELSE
        text = "WARNING: Equipment " + parameter + " approaching predefined threshold."
    END IF
    RETURN {equipment_id, parameter, value, status, text}
END FUNCTION
```

---

## f) Equipment Maintenance Monitoring

```
CONSTANT AVAILABILITY_THRESHOLD = 80   -- % below which equipment is "low availability"
CONSTANT DUE_SOON_WINDOW_DAYS = 7
CONSTANT REPEATED_ALERT_THRESHOLD = 3

FUNCTION CALCULATE_AVAILABILITY(operating_hours, downtime_hours):
    IF (operating_hours + downtime_hours) == 0 THEN
        RETURN 0
    END IF
    RETURN (operating_hours / (downtime_hours + operating_hours)) * 100
END FUNCTION

FUNCTION CHECK_MAINTENANCE_STATUS(equipment, maintenance_records, alerts, today):
    results = []
    FOR EACH item IN equipment:
        flags = []
        availability = CALCULATE_AVAILABILITY(item.operating_hours, item.downtime_hours)

        record = FIND_LATEST(maintenance_records, equipment_id == item.equipment_id)
        IF record IS NOT NULL THEN
            IF record.next_due_date < today THEN
                flags.ADD("Overdue")
            ELSE IF record.next_due_date <= today + DUE_SOON_WINDOW_DAYS THEN
                flags.ADD("Due Soon")
            END IF
            IF record.status == "In Progress" THEN
                flags.ADD("Under Maintenance")
            END IF
        END IF

        IF availability < AVAILABILITY_THRESHOLD THEN
            flags.ADD("Low Availability")
        END IF

        alert_count = COUNT(FILTER(alerts, source_id == item.equipment_id))
        IF alert_count > REPEATED_ALERT_THRESHOLD THEN
            flags.ADD("Repeated Alerts")
        END IF

        IF "Overdue" IN flags OR "Repeated Alerts" IN flags THEN
            RAISE_ALERT(source_type="Equipment", source_id=item.equipment_id,
                         parameter="Maintenance", value=availability, severity="Warning")
        END IF

        results.ADD({item.equipment_id, availability, flags})
    END FOR
    RETURN results
END FUNCTION
```

---

## g) Risk Assessment

```
FUNCTION CALCULATE_RISK(likelihood, consequence):
    IF likelihood NOT IN [1, 5] OR consequence NOT IN [1, 5] THEN
        RETURN ERROR("Likelihood and Consequence must be between 1 and 5")
    END IF

    risk_score = likelihood * consequence
    classification = CLASSIFY_RISK(risk_score)
    RETURN {risk_score, classification}
END FUNCTION

FUNCTION CLASSIFY_RISK(risk_score):
    IF risk_score <= 4 THEN RETURN "Low"
    ELSE IF risk_score <= 9 THEN RETURN "Medium"
    ELSE IF risk_score <= 16 THEN RETURN "High"
    ELSE RETURN "Critical"
    END IF
END FUNCTION

FUNCTION SUBMIT_RISK_ASSESSMENT(related_type, related_id, likelihood, consequence, assessed_by):
    result = CALCULATE_RISK(likelihood, consequence)
    IF result IS ERROR THEN RETURN result

    risk_id = GENERATE_ID()
    APPEND_ROW("risk_assessments.csv", {risk_id, related_type, related_id, likelihood, consequence,
                                         result.risk_score, result.classification,
                                         TODAY(), assessed_by})

    IF result.classification IN {"High", "Critical"} THEN
        DISPLAY_WARNING("High/Critical risk identified for " + related_type + " " + related_id)
        RAISE_ALERT(source_type=related_type, source_id=related_id, parameter="Risk Score",
                     value=result.risk_score, severity=result.classification)
    END IF

    RETURN SUCCESS(result)
END FUNCTION
```

---

## h) Alerts and Notifications

```
FUNCTION RAISE_ALERT(source_type, source_id, parameter, value, severity):
    alert_id = GENERATE_ID()
    message = FORMAT_ALERT_TEMPLATE(source_id, parameter, value, severity)

    APPEND_ROW("alerts.csv", {alert_id, TIMESTAMP_NOW(), source_type, source_id, parameter,
                               value, severity, message, acknowledged = FALSE})

    IF severity == "Critical" THEN
        DISPLAY_BANNER(message, style = "critical")
    ELSE
        DISPLAY_BANNER(message, style = "warning")
    END IF

    RETURN alert_id
END FUNCTION

FUNCTION FORMAT_ALERT_TEMPLATE(source_id, parameter, value, severity):
    RETURN
        "===============================\n" +
        "MINING MONITORING ALERT\n" +
        "===============================\n" +
        "[" + UPPER(severity) + "]\n" +
        "Equipment/Source ID: " + source_id + "\n" +
        "Parameter: " + parameter + "\n" +
        "Value: " + value + "\n" +
        "Status: Above " + severity + " Threshold\n" +
        "Recommended Action: Inspect and initiate appropriate maintenance/safety procedures.\n" +
        "==============================="
END FUNCTION

FUNCTION ACKNOWLEDGE_ALERT(alert_id):
    UPDATE_ROW("alerts.csv", alert_id, {acknowledged = TRUE})
END FUNCTION
```

---

## i) Mining Monitoring Dashboard

```
FUNCTION BUILD_DASHBOARD():
    workers      = LOAD_CSV("workers.csv")
    incidents    = LOAD_CSV("safety_incidents.csv")
    equipment    = LOAD_CSV("equipment.csv")
    maintenance  = LOAD_CSV("maintenance_records.csv")
    alerts       = LOAD_CSV("alerts.csv")

    kpis = {}
    kpis.total_workers          = COUNT(workers)
    kpis.total_incidents        = COUNT(incidents)
    kpis.near_misses            = SUM(workers.near_misses)
    kpis.high_risk_observations = COUNT(FILTER(workers, risk_level IN {"High", "Critical"}))
    kpis.avg_ppe_compliance     = AVERAGE(workers.ppe_compliance_pct)

    kpis.total_equipment        = COUNT(equipment)
    kpis.equipment_available    = COUNT(FILTER(equipment, maintenance_status == "Up to date"))
    kpis.equipment_under_maint  = COUNT(FILTER(equipment, maintenance_status == "Under Maintenance"))
    kpis.avg_availability       = AVERAGE_FOR_EACH(equipment, CALCULATE_AVAILABILITY)
    kpis.active_alerts          = COUNT(FILTER(alerts, acknowledged == FALSE))
    kpis.critical_alerts        = COUNT(FILTER(alerts, severity == "Critical" AND acknowledged == FALSE))

    RETURN kpis
END FUNCTION
```

---

## j) Interactive Data Analysis

```
CONSTANT QUESTION_REGISTRY = {
    "incidents_per_department": ANALYSE_INCIDENTS_BY_DEPARTMENT,
    "incidents_per_shift":      ANALYSE_INCIDENTS_BY_SHIFT,
    "ppe_compliance_pct":       ANALYSE_PPE_COMPLIANCE,
    "equipment_highest_downtime": ANALYSE_EQUIPMENT_DOWNTIME,
    "equipment_lowest_availability": ANALYSE_EQUIPMENT_AVAILABILITY,
    "equipment_most_alerts":    ANALYSE_EQUIPMENT_ALERTS,
    "dept_high_risk_and_downtime": ANALYSE_INTEGRATED_RISK
    -- ... remaining Appendix A questions map here similarly
}

FUNCTION ANSWER_QUESTION(question_key, filters = {}):
    IF question_key NOT IN QUESTION_REGISTRY THEN
        RETURN ERROR("Unknown question")
    END IF

    handler = QUESTION_REGISTRY[question_key]
    result = handler(filters)
    RETURN result
END FUNCTION

FUNCTION ANALYSE_INCIDENTS_BY_DEPARTMENT(filters):
    incidents = LOAD_CSV("safety_incidents.csv")
    incidents = APPLY_FILTERS(incidents, filters)
    grouped = GROUP_BY_COUNT(incidents, "department")
    RETURN {type = "ranked_table", data = SORT_DESC(grouped)}
END FUNCTION

FUNCTION ANALYSE_EQUIPMENT_DOWNTIME(filters):
    equipment = LOAD_CSV("equipment.csv")
    equipment = APPLY_FILTERS(equipment, filters)
    sorted_eq = SORT_DESC(equipment, "downtime_hours")
    RETURN {type = "ranked_table", data = sorted_eq}
END FUNCTION

FUNCTION ANALYSE_INTEGRATED_RISK(filters):
    incidents = LOAD_CSV("safety_incidents.csv")
    equipment = LOAD_CSV("equipment.csv")
    incident_counts = GROUP_BY_COUNT(incidents, "department")
    downtime_by_dept = GROUP_BY_SUM(equipment, "department", "downtime_hours")
    merged = JOIN(incident_counts, downtime_by_dept, ON = "department")
    flagged = FILTER(merged, incident_count > THRESHOLD AND downtime > THRESHOLD)
    RETURN {type = "ranked_table", data = flagged}
END FUNCTION
```
