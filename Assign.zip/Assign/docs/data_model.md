# Data Model — Mining Health, Safety and Equipment Monitoring Application

Storage: CSV files (minimum requirement per brief), one per entity, loaded/manipulated with Pandas.
Path convention: `data/<entity>.csv`

## 1. Entity-Relationship Overview

```mermaid
erDiagram
    USER ||--o{ ALERT : acknowledges
    WORKER ||--o{ SAFETY_INCIDENT : "involved in"
    WORKER ||--o{ RISK_ASSESSMENT : "assessed for"
    EQUIPMENT ||--o{ MAINTENANCE_RECORD : "has"
    EQUIPMENT ||--o{ ALERT : "generates"
    EQUIPMENT ||--o{ RISK_ASSESSMENT : "assessed for"
    SAFETY_INCIDENT ||--o{ RISK_ASSESSMENT : "assessed for"
    SAFETY_INCIDENT ||--o{ ALERT : "generates"

    USER {
        string user_id PK
        string username
        string password_hash
        string full_name
        string role
        bool active
    }
    WORKER {
        string worker_id PK
        string name
        string department
        string job_role
        string shift
        float ppe_compliance_pct
        string safety_training_status
        int fatigue_level
        int safety_observations
        int near_misses
        int previous_incidents
        string risk_level
    }
    SAFETY_INCIDENT {
        string incident_id PK
        string worker_id FK
        date date
        time time
        string shift
        string location
        string department
        string incident_type
        int severity
        string injury_status
        bool lost_time_injury
        string cause
        string corrective_action
        string incident_status
    }
    EQUIPMENT {
        string equipment_id PK
        string equipment_type
        string manufacturer
        float operating_hours
        float temperature
        float vibration
        float fuel_consumption
        string brake_status
        string tyre_status
        string engine_status
        string maintenance_status
        float downtime_hours
    }
    MAINTENANCE_RECORD {
        string maintenance_id PK
        string equipment_id FK
        date scheduled_date
        date completed_date
        string maintenance_type
        string description
        string status
        string technician
        date next_due_date
    }
    RISK_ASSESSMENT {
        string risk_id PK
        string related_type
        string related_id FK
        int likelihood
        int consequence
        int risk_score
        string classification
        date assessment_date
        string assessed_by
    }
    ALERT {
        string alert_id PK
        datetime timestamp
        string source_type
        string source_id FK
        string parameter
        float value
        string severity
        string message
        bool acknowledged
    }
```

## 2. Entity Field Definitions

### 2.1 `users.csv` — Access Control
| Field | Type | Notes |
|---|---|---|
| user_id | str | PK, e.g. `U001` |
| username | str | login handle |
| password_hash | str | never store plaintext |
| full_name | str | |
| role | str | one of: Administrator, Safety Officer, Mining Engineer, Maintenance Engineer, Manager |
| active | bool | disable without deleting |

Role → permission mapping is **not** stored per-user; it's a static lookup table (`ROLE_PERMISSIONS` dict in code) keyed by role, matching Table 1 of the brief. This keeps RBAC centrally defined and auditable.

### 2.2 `workers.csv` — Worker Health & Safety
| Field | Type | Notes |
|---|---|---|
| worker_id | str | PK |
| name | str | |
| department | str | e.g. Underground, Processing, Surface |
| job_role | str | |
| shift | str | Day / Night |
| ppe_compliance_pct | float | 0–100 |
| safety_training_status | str | Current / Expired / Pending |
| fatigue_level | int | 1–5 scale |
| safety_observations | int | count logged |
| near_misses | int | count |
| previous_incidents | int | count |
| risk_level | str | derived: Low/Medium/High/Critical from a worker-level risk score |

### 2.3 `safety_incidents.csv` — Incident Database
| Field | Type | Notes |
|---|---|---|
| incident_id | str | PK |
| worker_id | str | FK → workers, nullable |
| date, time, shift | date/time/str | |
| location, department | str | |
| incident_type | str | e.g. Fall, Equipment contact, Fire, Chemical exposure |
| severity | int | 1–5, feeds risk assessment |
| injury_status | str | None / First Aid / Medical Treatment / Lost Time |
| lost_time_injury | bool | |
| cause | str | free text / category |
| corrective_action | str | |
| incident_status | str | Open / Under Investigation / Closed |

### 2.4 `equipment.csv` — Equipment Database
| Field | Type | Notes |
|---|---|---|
| equipment_id | str | PK, e.g. `TRK-012` |
| equipment_type | str | Haul Truck, Loader, Excavator, Drill, Bulldozer, Scraper Winch, Crusher, Conveyor |
| manufacturer | str | |
| operating_hours | float | cumulative |
| temperature | float | °C, latest reading |
| vibration | float | mm/s, latest reading |
| fuel_consumption | float | l/hr |
| brake_status | str | OK / Warning / Fault |
| tyre_status | str | OK / Warning / Fault |
| engine_status | str | OK / Warning / Fault |
| maintenance_status | str | Up to date / Due / Overdue / Under Maintenance |
| downtime_hours | float | cumulative, used in availability calc |

`availability_pct` is **not** stored — always derived: `operating_hours / (operating_hours + downtime_hours) * 100`.

### 2.5 `maintenance_records.csv` — Maintenance Monitoring
| Field | Type | Notes |
|---|---|---|
| maintenance_id | str | PK |
| equipment_id | str | FK → equipment |
| scheduled_date | date | |
| completed_date | date | nullable — null means outstanding |
| maintenance_type | str | Preventive / Corrective / Inspection |
| description | str | |
| status | str | Scheduled / Due / Overdue / In Progress / Completed |
| technician | str | |
| next_due_date | date | drives "due/overdue" logic |

### 2.6 `risk_assessments.csv` — Risk Assessment
| Field | Type | Notes |
|---|---|---|
| risk_id | str | PK |
| related_type | str | Worker / Equipment / Incident / Department |
| related_id | str | FK to relevant table (polymorphic) |
| likelihood | int | 1–5 |
| consequence | int | 1–5 |
| risk_score | int | derived = likelihood × consequence |
| classification | str | derived: Low(1-4) / Medium(5-9) / High(10-16) / Critical(17-25) |
| assessment_date | date | |
| assessed_by | str | user_id |

### 2.7 `alerts.csv` — Alerts & Notifications (log)
| Field | Type | Notes |
|---|---|---|
| alert_id | str | PK |
| timestamp | datetime | |
| source_type | str | Equipment / Worker / Incident / Maintenance |
| source_id | str | FK to relevant table |
| parameter | str | e.g. Temperature, Vibration, PPE Compliance, Fatigue |
| value | float | the triggering value |
| severity | str | Warning / Critical |
| message | str | human-readable, formatted per Figure 1 |
| acknowledged | bool | for dashboard "active alerts" count |

## 3. Derived / Computed Fields (never stored as raw truth, always calculated at read time)
- `Equipment.availability_pct` — availability formula
- `Equipment.condition_status` (per parameter) — Normal/Warning/Critical from threshold table
- `Worker.risk_level` — can be derived from fatigue_level, ppe_compliance, previous_incidents composite, or sourced from a linked `risk_assessments` row
- `RiskAssessment.risk_score`, `.classification`
- `Alert` rows are *generated* by the monitoring functions (condition monitoring, maintenance monitoring, worker safety monitoring, risk assessment) and appended to the alert log — alerts are an output, not manually entered

## 4. Why this shape
- One CSV per entity keeps read/filter/group operations simple in Pandas and matches the brief's minimum storage requirement; SQLite can later replace the CSV layer without changing the logic layer if `related_id`/foreign-key-style string IDs are used consistently now.
- Keeping RBAC as a static role→permission table (not per-user rows) means Table 1 from the brief is literally the source of truth in code, and adding a new permission is a one-line change.
- Separating `alerts.csv` as a generated log (rather than recomputing alerts fresh every run) lets the app track "equipment with repeated alerts" and "active/acknowledged" counts for the dashboard.
