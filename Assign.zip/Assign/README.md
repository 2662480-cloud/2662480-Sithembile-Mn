# Mining Health, Safety & Equipment Monitoring App

A Streamlit application for the MINN2020A project brief: role-based access to worker
safety, incident, equipment, maintenance, risk and alert data for a mine site, backed
by CSV files and Pandas.

## 1. Setup

```bash
pip install -r requirements.txt
```

Requires Python 3.10+.

## 2. Running the app

From the project root:

```bash
streamlit run app.py
```

This opens the app in your browser (usually `http://localhost:8501`).

The app already ships with a populated demo dataset in `data/*.csv`. To wipe it and
generate a fresh, randomised (but reproducible) dataset instead:

```bash
python -m src.data_generator
```

## 3. Logging in

You'll land on a login screen. Use any of these demo accounts — all share the same
password:

| Username    | Role                  | Password      |
|-------------|-----------------------|---------------|
| `admin`     | Administrator         | `password123` |
| `safety1`   | Safety Officer        | `password123` |
| `mining1`   | Mining Engineer       | `password123` |
| `maint1`    | Maintenance Engineer  | `password123` |
| `manager1`  | Manager               | `password123` |

The menu you see after logging in is filtered to what your role is allowed to access
(see the table in section 5).

## 4. Navigating the app

Once logged in, use the sidebar to move between pages. Your name and role are shown
at the top of the sidebar, with a **Log out** button below.

If any equipment or incident has raised an unacknowledged **Critical** alert, a red
banner appears at the top of most pages — expand it to preview the alert messages, or
head to the **Alerts** page to acknowledge them.

### 📊 Dashboard
The landing page after login (for every role). Shows headline KPIs — worker counts,
incidents, near misses, PPE compliance, equipment availability, active/critical alert
counts — plus charts (incidents by department, equipment status breakdown) and a table
of equipment currently flagged for attention.

### 🔔 Alerts
Every alert raised by the system (from worker risk, incident severity, equipment
condition, maintenance status, or risk assessments). Filter by active/acknowledged and
by severity. Click **Acknowledge** on a row to clear it from the active count.

### 🧑‍🏭 Workers
- **View / Filter Workers** — browse and filter the workforce by department, shift, or
  risk level; a summary shows low-PPE, high-fatigue, and high-risk counts.
- **Add Worker** — register a new worker. Risk level is calculated automatically from
  PPE compliance, fatigue, near-misses, and prior incidents; High/Critical risk raises
  an alert automatically.

### 🚨 Safety Incidents
- **Search / View** — search and filter the incident log by text, department, shift,
  or status.
- **Add Incident** — log a new incident. Severity 4–5 automatically raises a critical
  alert.
- **Analyse Trends** — charts of incidents by department, shift, and type, plus a count
  of high/critical-severity incidents.

### 🚜 Equipment
- **View Equipment** — browse the fleet, filterable by type and maintenance status,
  with availability % calculated live.
- **Add / Update Equipment** — register new equipment or update an existing record by
  ID (the same ID overwrites rather than duplicates).
- **Condition Monitoring** — click **Run condition monitoring check** to evaluate
  every item's current temperature/vibration against warning/critical thresholds and
  raise alerts for anything abnormal.

### 🛠️ Maintenance
- **Maintenance Status** — click **Run maintenance monitoring check** to flag
  equipment as Overdue, Due Soon, Low Availability, or Repeated Alerts, and raise
  alerts where needed.
- **Add Maintenance Record** — schedule a new maintenance record against an existing
  piece of equipment.
- **Complete Record** — mark an outstanding record as completed, which also resets the
  equipment's maintenance status.

### ⚠️ Risk Assessment
Submit a Likelihood × Consequence assessment (1–5 each) against a worker, piece of
equipment, incident, or department. The risk score and classification
(Low/Medium/High/Critical) are calculated automatically; High/Critical results show a
warning and raise an alert. Below the form, browse all recorded assessments with
filters.

### 📈 Interactive Analysis
Pick a category (Health & Safety / Equipment / Integrated) and a business question from
a dropdown — the answer renders as a metric, ranked table, or chart depending on the
question (e.g. "Which equipment has the highest downtime?", "How are lost-time injuries
trending month over month?").

### 🔐 Manage Users (Administrator only)
View all user accounts, add a new one (with a role and password), and enable/disable
existing accounts.

## 5. Roles and permissions

| Feature              | Administrator | Safety Officer | Mining Engineer | Maintenance Engineer | Manager |
|-----------------------|:---:|:---:|:---:|:---:|:---:|
| Dashboard / Alerts     | ✅ | ✅ | ✅ | ✅ | ✅ |
| Workers                | ✅ | ✅ | ✅ |    | ✅ |
| Safety Incidents       | ✅ | ✅ | ✅ |    | ✅ |
| Equipment              | ✅ |    | ✅ | ✅ | ✅ |
| Maintenance            | ✅ |    | ✅ | ✅ | ✅ |
| Risk Assessment        | ✅ | ✅ | ✅ |    | ✅ |
| Interactive Analysis   | ✅ | ✅ | ✅ | ✅ | ✅ |
| Manage Users           | ✅ |    |    |    |    |

This mapping lives in `src/config.py` (`ROLE_PERMISSIONS`) — see `docs/data_model.md`
for the full data model and `docs/pseudocode.md` for the logic each page is built on.

## 6. Running the tests

```bash
pytest
```

Tests never touch your real `data/*.csv` — they run against an isolated temp directory
(see `tests/conftest.py`). If a page ever fails at runtime instead of in tests, check
`logs/app.log`, which every page's errors are logged to automatically.
