from src import data_loader, risk


def test_submit_risk_assessment_low(isolated_data_dir):
    result, error = risk.submit_risk_assessment("Worker", "W001", 1, 2, "U001")
    assert error is None
    assert result["risk_score"] == 2
    assert result["classification"] == "Low"
    assert result["warning"] is False
    assert data_loader.load_alerts().empty


def test_submit_risk_assessment_critical_raises_alert(isolated_data_dir):
    result, error = risk.submit_risk_assessment("Equipment", "EQ1", 5, 5, "U001")
    assert error is None
    assert result["classification"] == "Critical"
    assert result["warning"] is True

    alerts_df = data_loader.load_alerts()
    assert len(alerts_df) == 1
    assert alerts_df.iloc[0]["source_id"] == "EQ1"
    assert alerts_df.iloc[0]["severity"] == "Critical"


def test_submit_risk_assessment_invalid_related_type(isolated_data_dir):
    result, error = risk.submit_risk_assessment("Spaceship", "X", 1, 1, "U001")
    assert result is None
    assert "related_type" in error


def test_submit_risk_assessment_invalid_likelihood(isolated_data_dir):
    result, error = risk.submit_risk_assessment("Worker", "W001", 0, 3, "U001")
    assert result is None
    assert "Likelihood" in error


def test_list_risk_assessments_sorted_by_score_desc(isolated_data_dir):
    risk.submit_risk_assessment("Worker", "W001", 1, 1, "U001")
    risk.submit_risk_assessment("Worker", "W002", 5, 5, "U001")
    results = risk.list_risk_assessments()
    assert results.iloc[0]["risk_score"] == 25
    assert results.iloc[-1]["risk_score"] == 1


def test_list_risk_assessments_filters_by_classification(isolated_data_dir):
    risk.submit_risk_assessment("Worker", "W001", 1, 1, "U001")  # Low
    risk.submit_risk_assessment("Worker", "W002", 5, 5, "U001")  # Critical
    results = risk.list_risk_assessments(classification="Critical")
    assert len(results) == 1
    assert results.iloc[0]["related_id"] == "W002"
