from datetime import date, timedelta

from src import data_loader, equipment, maintenance


def _seed_equipment(equipment_id="EQ1", operating_hours=100, downtime_hours=20):
    equipment.add_or_update_equipment(
        equipment_id, "Loader", "Cat", operating_hours, 60, 2, 20,
        "OK", "OK", "OK", "Up to date", downtime_hours,
    )


def test_add_maintenance_record_unknown_equipment_rejected(isolated_data_dir):
    maintenance_id, error = maintenance.add_maintenance_record(
        "GHOST", scheduled_date=str(date.today()), maintenance_type="Preventive",
        description="x", technician="Bob", next_due_date=str(date.today()),
    )
    assert maintenance_id is None
    assert "Unknown" in error


def test_add_maintenance_record_in_progress_marks_equipment_under_maintenance(isolated_data_dir):
    _seed_equipment("EQ1")
    maintenance.add_maintenance_record(
        "EQ1", scheduled_date=str(date.today()), maintenance_type="Corrective",
        description="repair", technician="Bob", next_due_date=str(date.today()),
        status="In Progress",
    )
    row = equipment.get_equipment("EQ1")
    assert row["maintenance_status"] == "Under Maintenance"


def test_complete_maintenance_record_updates_equipment_status(isolated_data_dir):
    _seed_equipment("EQ1")
    maintenance_id, _ = maintenance.add_maintenance_record(
        "EQ1", scheduled_date=str(date.today()), maintenance_type="Preventive",
        description="x", technician="Bob", next_due_date=str(date.today()), status="In Progress",
    )
    ok = maintenance.complete_maintenance_record(maintenance_id, str(date.today()))
    assert ok is True
    assert equipment.get_equipment("EQ1")["maintenance_status"] == "Up to date"


def test_complete_maintenance_record_unknown_id_returns_false(isolated_data_dir):
    assert maintenance.complete_maintenance_record("GHOST", str(date.today())) is False


def test_run_maintenance_monitoring_flags_overdue(isolated_data_dir):
    _seed_equipment("EQ1", operating_hours=100, downtime_hours=5)
    overdue_due_date = date.today() - timedelta(days=10)
    maintenance.add_maintenance_record(
        "EQ1", scheduled_date=str(overdue_due_date - timedelta(days=30)),
        maintenance_type="Preventive", description="check", technician="Bob",
        next_due_date=str(overdue_due_date),
    )
    summary = maintenance.run_maintenance_monitoring()
    assert "Overdue" in summary.iloc[0]["flags"]


def test_run_maintenance_monitoring_flags_low_availability(isolated_data_dir):
    _seed_equipment("EQ1", operating_hours=50, downtime_hours=100)  # 33% availability
    summary = maintenance.run_maintenance_monitoring()
    assert "Low Availability" in summary.iloc[0]["flags"]


def test_run_maintenance_monitoring_ok_when_nothing_flagged(isolated_data_dir):
    _seed_equipment("EQ1", operating_hours=1000, downtime_hours=10)
    summary = maintenance.run_maintenance_monitoring()
    assert summary.iloc[0]["flags"] == "OK"


def test_run_maintenance_monitoring_repeated_alerts_flag(isolated_data_dir):
    from src import alerts
    _seed_equipment("EQ1", operating_hours=1000, downtime_hours=10)
    for _ in range(4):
        alerts.raise_alert("Equipment", "EQ1", "Temperature", 110, "Critical")
    summary = maintenance.run_maintenance_monitoring()
    assert "Repeated Alerts" in summary.iloc[0]["flags"]


def test_equipment_needing_attention_filters_ok_rows(isolated_data_dir):
    _seed_equipment("EQ1", operating_hours=1000, downtime_hours=10)  # OK
    _seed_equipment("EQ2", operating_hours=50, downtime_hours=100)  # Low Availability
    attention = maintenance.equipment_needing_attention()
    assert list(attention["equipment_id"]) == ["EQ2"]
