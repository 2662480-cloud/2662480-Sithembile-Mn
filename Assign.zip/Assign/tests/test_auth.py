import pandas as pd
import pytest

from src import auth, config, data_loader


@pytest.fixture
def seeded_users(isolated_data_dir):
    users = pd.DataFrame([
        {"user_id": "U001", "username": "admin", "password_hash": auth.hash_password("secret123"),
         "full_name": "Site Admin", "role": "Administrator", "active": True},
        {"user_id": "U002", "username": "disabled_user", "password_hash": auth.hash_password("secret123"),
         "full_name": "Disabled Person", "role": "Manager", "active": False},
    ])
    data_loader.save_csv(config.USERS_CSV, users)
    return users


def test_login_success_grants_role_permissions(seeded_users):
    session, error = auth.login("admin", "secret123")
    assert error is None
    assert session.role == "Administrator"
    assert "manage_users" in session.permissions


def test_login_wrong_password(seeded_users):
    session, error = auth.login("admin", "wrong-password")
    assert session is None
    assert "Invalid" in error


def test_login_unknown_username(seeded_users):
    session, error = auth.login("nobody", "secret123")
    assert session is None
    assert "Invalid" in error


def test_login_disabled_account(seeded_users):
    session, error = auth.login("disabled_user", "secret123")
    assert session is None
    assert "disabled" in error.lower()


def test_has_permission_none_session_is_false():
    assert auth.has_permission(None, "dashboard") is False


def test_has_permission_checks_role_permission_set(seeded_users):
    session, _ = auth.login("admin", "secret123")
    assert auth.has_permission(session, "manage_users") is True
    assert auth.has_permission(session, "not_a_real_permission") is False


def test_hash_password_deterministic_and_distinct():
    assert auth.hash_password("abc") == auth.hash_password("abc")
    assert auth.hash_password("abc") != auth.hash_password("abd")
