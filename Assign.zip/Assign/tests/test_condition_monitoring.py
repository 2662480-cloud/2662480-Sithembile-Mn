import pandas as pd

from src import condition_monitoring, data_loader, equipment


def test_evaluate_equipment_condition_all_normal():
    result = condition_monitoring.evaluate_equipment_condition("EQ1", 50, 2)
    assert result["overall_status"] == "Normal"
    assert result["messages"] == []


def test_evaluate_equipment_condition_critical_temperature():
    result = condition_monitoring.evaluate_equipment_condition("EQ1", 110, 2)
    assert result["temperature_status"] == "Critical"
    assert result["vibration_status"] == "Normal"
    assert result["overall_status"] == "Critical"
    assert len(result["messages"]) == 1


def test_evaluate_equipment_condition_both_warning_overall_is_warning():
    result = condition_monitoring.evaluate_equipment_condition("EQ1", 85, 6)
    assert result["temperature_status"] == "Warning"
    assert result["vibration_status"] == "Warning"
    assert result["overall_status"] == "Warning"
    assert len(result["messages"]) == 2


def test_run_condition_monitoring_no_alerts_by_default(isolated_data_dir):
    equipment.add_or_update_equipment(
        "EQ1", "Loader", "Cat", 100, 110, 2, 10, "OK", "OK", "OK", "Up to date", 5,
    )
    summary = condition_monitoring.run_condition_monitoring()
    assert summary.iloc[0]["overall_status"] == "Critical"
    assert data_loader.load_alerts().empty  # raise_alerts defaults to False


def test_run_condition_monitoring_raises_alerts_when_asked(isolated_data_dir):
    equipment.add_or_update_equipment(
        "EQ1", "Loader", "Cat", 100, 110, 2, 10, "OK", "OK", "OK", "Up to date", 5,
    )
    condition_monitoring.run_condition_monitoring(raise_alerts=True)

    alerts_df = data_loader.load_alerts()
    assert len(alerts_df) == 1
    assert alerts_df.iloc[0]["parameter"] == "Temperature"
    assert alerts_df.iloc[0]["severity"] == "Critical"


def test_run_condition_monitoring_empty_equipment(isolated_data_dir):
    summary = condition_monitoring.run_condition_monitoring(equipment=pd.DataFrame())
    assert summary.empty
