import logging

import pytest

from src import config, error_logging


@pytest.fixture
def isolated_log_dir(tmp_path, monkeypatch):
    """Point error_logging at a tmp directory and make sure no handler from an
    earlier test (or an earlier app run) is left attached to the shared
    logger, so each test starts from a clean slate."""
    monkeypatch.setattr(config, "BASE_DIR", tmp_path)
    logger = logging.getLogger(error_logging.LOGGER_NAME)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
    yield tmp_path
    for handler in list(logger.handlers):
        logger.removeHandler(handler)


def test_log_errors_catches_exception_logs_it_and_does_not_propagate(isolated_log_dir, monkeypatch):
    import streamlit as st
    shown_messages = []
    monkeypatch.setattr(st, "error", lambda msg: shown_messages.append(msg))

    @error_logging.log_errors("Broken Page")
    def broken():
        raise ValueError("boom")

    result = broken()  # must not raise

    assert result is None
    assert len(shown_messages) == 1
    assert "Broken Page" in shown_messages[0]

    log_file = isolated_log_dir / "logs" / "app.log"
    assert log_file.exists()
    contents = log_file.read_text(encoding="utf-8")
    assert "Broken Page" in contents
    assert "boom" in contents
    assert "ValueError" in contents
    assert "Traceback" in contents


def test_log_errors_passes_through_return_value_on_success(isolated_log_dir):
    @error_logging.log_errors("Fine Page")
    def fine():
        return 42

    assert fine() == 42

    log_file = isolated_log_dir / "logs" / "app.log"
    assert not log_file.exists()


def test_log_errors_passes_through_arguments(isolated_log_dir):
    @error_logging.log_errors("Adder")
    def add(a, b):
        return a + b

    assert add(2, 3) == 5


def test_get_logger_reuses_same_logger_and_single_handler(isolated_log_dir):
    logger1 = error_logging.get_logger()
    logger2 = error_logging.get_logger()
    assert logger1 is logger2

    file_handlers = [h for h in logger2.handlers if isinstance(h, logging.FileHandler)]
    assert len(file_handlers) == 1
    assert file_handlers[0].baseFilename == str(isolated_log_dir / "logs" / "app.log")


def test_get_logger_switches_handler_when_base_dir_changes(isolated_log_dir, tmp_path_factory, monkeypatch):
    error_logging.get_logger()
    other_dir = tmp_path_factory.mktemp("other_base")
    monkeypatch.setattr(config, "BASE_DIR", other_dir)

    logger = error_logging.get_logger()
    file_handlers = [h for h in logger.handlers if isinstance(h, logging.FileHandler)]
    assert len(file_handlers) == 1
    assert file_handlers[0].baseFilename == str(other_dir / "logs" / "app.log")


def test_multiple_errors_are_all_logged(isolated_log_dir, monkeypatch):
    import streamlit as st
    monkeypatch.setattr(st, "error", lambda msg: None)

    @error_logging.log_errors("Flaky Page")
    def flaky():
        raise RuntimeError("first failure")

    flaky()
    flaky()

    log_file = isolated_log_dir / "logs" / "app.log"
    contents = log_file.read_text(encoding="utf-8")
    assert contents.count("Flaky Page") == 2
