from src import data_loader, workers


def test_add_worker_success(isolated_data_dir):
    worker_id, error = workers.add_worker(
        name="Jane Doe", department="Underground", job_role="Operator", shift="Day",
        ppe_compliance_pct=95, safety_training_status="Current", fatigue_level=2,
        safety_observations=1, near_misses=0, previous_incidents=0,
    )
    assert error is None
    assert worker_id == "W001"


def test_add_worker_invalid_ppe_range(isolated_data_dir):
    worker_id, error = workers.add_worker(
        name="Jane Doe", department="Underground", job_role="Operator", shift="Day",
        ppe_compliance_pct=150, safety_training_status="Current", fatigue_level=2,
        safety_observations=1, near_misses=0, previous_incidents=0,
    )
    assert worker_id is None
    assert "PPE" in error


def test_add_worker_invalid_fatigue_range(isolated_data_dir):
    worker_id, error = workers.add_worker(
        name="Jane Doe", department="Underground", job_role="Operator", shift="Day",
        ppe_compliance_pct=90, safety_training_status="Current", fatigue_level=9,
        safety_observations=1, near_misses=0, previous_incidents=0,
    )
    assert worker_id is None
    assert "Fatigue" in error


def test_add_worker_missing_required_fields(isolated_data_dir):
    worker_id, error = workers.add_worker(
        name="", department="Underground", job_role="Operator", shift="Day",
        ppe_compliance_pct=90, safety_training_status="Current", fatigue_level=2,
        safety_observations=0, near_misses=0, previous_incidents=0,
    )
    assert worker_id is None
    assert error is not None


def test_add_worker_high_risk_raises_alert(isolated_data_dir):
    worker_id, error = workers.add_worker(
        name="At Risk", department="Surface", job_role="Operator", shift="Night",
        ppe_compliance_pct=40, safety_training_status="Expired", fatigue_level=5,
        safety_observations=0, near_misses=4, previous_incidents=3,
    )
    assert error is None
    alerts_df = data_loader.load_alerts()
    assert len(alerts_df) == 1
    assert alerts_df.iloc[0]["source_id"] == worker_id
    assert alerts_df.iloc[0]["severity"] in {"High", "Critical"}


def test_add_worker_low_risk_does_not_raise_alert(isolated_data_dir):
    workers.add_worker(
        name="Fine", department="Surface", job_role="Operator", shift="Day",
        ppe_compliance_pct=95, safety_training_status="Current", fatigue_level=1,
        safety_observations=2, near_misses=0, previous_incidents=0,
    )
    assert data_loader.load_alerts().empty


def test_view_workers_filters_by_department(isolated_data_dir):
    workers.add_worker("A", "Underground", "Op", "Day", 90, "Current", 1, 0, 0, 0)
    workers.add_worker("B", "Surface", "Op", "Night", 90, "Current", 1, 0, 0, 0)
    result = workers.view_workers(department="Surface")
    assert len(result) == 1
    assert result.iloc[0]["department"] == "Surface"


def test_unsafe_conditions_summary_counts_correctly(isolated_data_dir):
    workers.add_worker("Low PPE", "Underground", "Op", "Day", 50, "Current", 1, 0, 0, 0)
    workers.add_worker("Tired", "Underground", "Op", "Day", 95, "Current", 4, 0, 0, 0)
    summary = workers.unsafe_conditions_summary()
    assert summary["low_ppe_compliance"] == 1
    assert summary["high_fatigue"] == 1


def test_unsafe_conditions_summary_empty(isolated_data_dir):
    assert workers.unsafe_conditions_summary() == {
        "low_ppe_compliance": 0, "high_fatigue": 0, "high_risk_workers": 0,
    }
