import pytest

from src import rules


def test_calculate_availability_normal():
    assert rules.calculate_availability(80, 20) == 80.0


def test_calculate_availability_zero_total_is_zero():
    assert rules.calculate_availability(0, 0) == 0.0


@pytest.mark.parametrize("value,expected", [
    (50, "Normal"), (79.9, "Normal"), (80, "Warning"), (99.9, "Warning"), (100.1, "Critical"),
])
def test_classify_temperature(value, expected):
    assert rules.classify_temperature(value) == expected


@pytest.mark.parametrize("value,expected", [
    (4.9, "Normal"), (5, "Warning"), (7.9, "Warning"), (8.1, "Critical"),
])
def test_classify_vibration(value, expected):
    assert rules.classify_vibration(value) == expected


def test_worst_status_picks_highest_severity():
    assert rules.worst_status("Normal", "Warning") == "Warning"
    assert rules.worst_status("Warning", "Critical") == "Critical"
    assert rules.worst_status("Normal", "Normal") == "Normal"


def test_build_condition_message_normal_is_none():
    assert rules.build_condition_message("EQ1", "Temperature", 50, "Normal") is None


def test_build_condition_message_critical_wording():
    msg = rules.build_condition_message("EQ1", "Temperature", 120, "Critical")
    assert "CRITICAL" in msg
    assert "Inspection required" in msg


def test_build_condition_message_warning_wording():
    msg = rules.build_condition_message("EQ1", "Vibration", 6, "Warning")
    assert "WARNING" in msg


@pytest.mark.parametrize("score,expected", [
    (1, "Low"), (4, "Low"),
    (5, "Medium"), (9, "Medium"),
    (10, "High"), (16, "High"),
    (17, "Critical"), (25, "Critical"),
])
def test_classify_risk_boundaries(score, expected):
    assert rules.classify_risk(score) == expected


def test_calculate_risk_score():
    assert rules.calculate_risk_score(3, 4) == 12


@pytest.mark.parametrize("likelihood,consequence", [(0, 3), (6, 3), (3, 0), (3, 6)])
def test_calculate_risk_score_out_of_range_raises(likelihood, consequence):
    with pytest.raises(ValueError):
        rules.calculate_risk_score(likelihood, consequence)


def test_evaluate_worker_risk_low():
    assert rules.evaluate_worker_risk(95, 1, 0, 0) == "Low"


def test_evaluate_worker_risk_critical():
    # low PPE (+2) + high fatigue (+2) + previous incidents (+2) = 6 -> Critical
    assert rules.evaluate_worker_risk(50, 5, 0, 3) == "Critical"


def test_evaluate_worker_risk_medium():
    # near_misses >= 3 only -> +1 -> Medium
    assert rules.evaluate_worker_risk(90, 1, 3, 0) == "Medium"


def test_format_alert_message_contains_key_fields():
    msg = rules.format_alert_message("EQ1", "Temperature", 105, "Critical")
    assert "EQ1" in msg
    assert "Temperature" in msg
    assert "[CRITICAL]" in msg
