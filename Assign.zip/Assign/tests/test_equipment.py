from src import equipment, rules


def _add(equipment_id="TRK-001", operating_hours=100, downtime_hours=20, **overrides):
    kwargs = dict(
        equipment_id=equipment_id, equipment_type="Haul Truck", manufacturer="Cat",
        operating_hours=operating_hours, temperature=60, vibration=2, fuel_consumption=50,
        brake_status="OK", tyre_status="OK", engine_status="OK",
        maintenance_status="Up to date", downtime_hours=downtime_hours,
    )
    kwargs.update(overrides)
    return equipment.add_or_update_equipment(**kwargs)


def test_add_and_view_equipment(isolated_data_dir):
    ok, error = _add()
    assert ok is True
    assert error is None

    view = equipment.view_equipment()
    assert len(view) == 1
    assert view.iloc[0]["availability_pct"] == rules.calculate_availability(100, 20)


def test_add_or_update_equipment_updates_existing_row(isolated_data_dir):
    _add(operating_hours=100)
    _add(operating_hours=200, maintenance_status="Due")

    view = equipment.view_equipment()
    assert len(view) == 1  # updated, not duplicated
    assert view.iloc[0]["operating_hours"] == 200
    assert view.iloc[0]["maintenance_status"] == "Due"


def test_add_equipment_invalid_status_rejected(isolated_data_dir):
    ok, error = _add(brake_status="Broken")
    assert ok is False
    assert "Brake" in error


def test_add_equipment_negative_hours_rejected(isolated_data_dir):
    ok, error = _add(operating_hours=-1)
    assert ok is False
    assert "negative" in error.lower()


def test_add_equipment_missing_id_rejected(isolated_data_dir):
    ok, error = _add(equipment_id="")
    assert ok is False


def test_view_equipment_filters_by_type_and_status(isolated_data_dir):
    _add(equipment_id="TRK-001", equipment_type="Haul Truck", maintenance_status="Up to date")
    _add(equipment_id="LDR-001", equipment_type="Loader", maintenance_status="Overdue")

    loaders = equipment.view_equipment(equipment_type="Loader")
    assert len(loaders) == 1
    assert loaders.iloc[0]["equipment_id"] == "LDR-001"

    overdue = equipment.view_equipment(maintenance_status="Overdue")
    assert len(overdue) == 1
    assert overdue.iloc[0]["equipment_id"] == "LDR-001"


def test_get_equipment_returns_none_when_missing(isolated_data_dir):
    assert equipment.get_equipment("GHOST") is None


def test_get_equipment_returns_row(isolated_data_dir):
    _add(equipment_id="TRK-001")
    row = equipment.get_equipment("TRK-001")
    assert row is not None
    assert row["equipment_id"] == "TRK-001"
