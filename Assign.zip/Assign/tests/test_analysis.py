import pytest

from src import analysis, equipment, workers


def test_answer_question_unknown_key_raises():
    with pytest.raises(ValueError):
        analysis.answer_question("does_not_exist")


def test_incidents_by_department_empty(isolated_data_dir):
    result = analysis.answer_question("incidents_by_department")
    assert result["result_type"] == "chart"
    assert result["series"].empty


def test_high_risk_worker_count_metric(isolated_data_dir):
    workers.add_worker("A", "Underground", "Op", "Day", 40, "Expired", 5, 0, 4, 3)  # -> Critical
    workers.add_worker("B", "Underground", "Op", "Day", 95, "Current", 1, 0, 0, 0)  # -> Low
    result = analysis.answer_question("high_risk_worker_count")
    assert result["result_type"] == "metric"
    assert result["value"] == 1


def test_equipment_highest_downtime_ranks_descending(isolated_data_dir):
    equipment.add_or_update_equipment("EQ1", "Loader", "Cat", 100, 60, 2, 20,
                                       "OK", "OK", "OK", "Up to date", 5)
    equipment.add_or_update_equipment("EQ2", "Loader", "Cat", 100, 60, 2, 20,
                                       "OK", "OK", "OK", "Up to date", 50)
    result = analysis.answer_question("equipment_highest_downtime")
    assert result["result_type"] == "table"
    assert result["data"].iloc[0]["equipment_id"] == "EQ2"


def test_equipment_lowest_availability_ranks_ascending(isolated_data_dir):
    equipment.add_or_update_equipment("EQ1", "Loader", "Cat", 900, 60, 2, 20,
                                       "OK", "OK", "OK", "Up to date", 10)  # high availability
    equipment.add_or_update_equipment("EQ2", "Loader", "Cat", 50, 60, 2, 20,
                                       "OK", "OK", "OK", "Up to date", 100)  # low availability
    result = analysis.answer_question("equipment_lowest_availability")
    assert result["data"].iloc[0]["equipment_id"] == "EQ2"


def test_every_registered_question_runs_without_error(isolated_data_dir):
    """Guards against a question in the registry crashing on empty or partial data."""
    equipment.add_or_update_equipment("EQ1", "Loader", "Cat", 100, 60, 2, 20,
                                       "OK", "OK", "OK", "Up to date", 5)
    workers.add_worker("A", "Underground", "Op", "Day", 40, "Expired", 5, 0, 4, 3)

    for key in analysis.QUESTION_REGISTRY:
        result = analysis.answer_question(key)
        assert result["result_type"] in {"metric", "table", "chart"}


def test_question_registry_categories_are_valid():
    for key, definition in analysis.QUESTION_REGISTRY.items():
        assert definition["category"] in analysis.CATEGORIES, key
