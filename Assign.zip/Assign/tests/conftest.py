import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src import config

ENTITY_ATTRS = [
    "USERS_CSV", "WORKERS_CSV", "INCIDENTS_CSV", "EQUIPMENT_CSV",
    "MAINTENANCE_CSV", "RISK_CSV", "ALERTS_CSV",
]


@pytest.fixture
def isolated_data_dir(tmp_path, monkeypatch):
    """Redirect every src/config CSV path to a per-test tmp directory so tests
    never read or write the project's real data/*.csv files.

    Every src module looks up config.<X>_CSV / config.SCHEMAS fresh at call
    time (never imports the Path objects directly), so monkeypatching the
    config module attributes here is enough to isolate the whole data layer.
    """
    monkeypatch.setattr(config, "DATA_DIR", tmp_path)

    new_schemas = {}
    for attr in ENTITY_ATTRS:
        old_path = getattr(config, attr)
        columns = config.SCHEMAS[old_path]
        new_path = tmp_path / old_path.name
        monkeypatch.setattr(config, attr, new_path)
        new_schemas[new_path] = columns

    monkeypatch.setattr(config, "SCHEMAS", new_schemas)
    return tmp_path
