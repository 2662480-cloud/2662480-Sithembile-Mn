from src import config, data_loader


def test_load_csv_missing_file_returns_empty_with_correct_columns(isolated_data_dir):
    df = data_loader.load_csv(config.USERS_CSV)
    assert list(df.columns) == config.SCHEMAS[config.USERS_CSV]
    assert df.empty


def test_append_row_and_load(isolated_data_dir):
    data_loader.append_row(config.WORKERS_CSV, {
        "worker_id": "W001", "name": "A", "department": "Underground", "job_role": "Op",
        "shift": "Day", "ppe_compliance_pct": 90, "safety_training_status": "Current",
        "fatigue_level": 1, "safety_observations": 0, "near_misses": 0,
        "previous_incidents": 0, "risk_level": "Low",
    })
    df = data_loader.load_workers()
    assert len(df) == 1
    assert df.iloc[0]["worker_id"] == "W001"


def test_next_id_starts_at_one(isolated_data_dir):
    assert data_loader.next_id(config.WORKERS_CSV, "worker_id", "W") == "W001"


def test_next_id_sequential_after_existing_rows(isolated_data_dir):
    data_loader.append_row(config.WORKERS_CSV, {"worker_id": "W001"})
    data_loader.append_row(config.WORKERS_CSV, {"worker_id": "W002"})
    assert data_loader.next_id(config.WORKERS_CSV, "worker_id", "W") == "W003"


def test_update_row_updates_matching_row(isolated_data_dir):
    data_loader.append_row(config.EQUIPMENT_CSV, {"equipment_id": "EQ1", "maintenance_status": "Up to date"})
    updated = data_loader.update_row(config.EQUIPMENT_CSV, "equipment_id", "EQ1",
                                      {"maintenance_status": "Overdue"})
    assert updated is True
    df = data_loader.load_equipment()
    assert df.iloc[0]["maintenance_status"] == "Overdue"


def test_update_row_missing_id_returns_false(isolated_data_dir):
    updated = data_loader.update_row(config.EQUIPMENT_CSV, "equipment_id", "GHOST", {"x": 1})
    assert updated is False


def test_isolation_fixture_redirects_away_from_real_project_data(isolated_data_dir):
    """Guardrail: config.DATA_DIR must point at the tmp dir, not the real data/ dir
    (config.BASE_DIR is left untouched by the fixture, so it's the reference point)."""
    real_data_dir = config.BASE_DIR / "data"
    assert config.DATA_DIR == isolated_data_dir
    assert config.DATA_DIR != real_data_dir
