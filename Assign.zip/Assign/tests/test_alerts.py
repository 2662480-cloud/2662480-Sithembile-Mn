from src import alerts


def test_raise_alert_creates_row(isolated_data_dir):
    alert_id = alerts.raise_alert("Equipment", "EQ1", "Temperature", 110, "Critical")
    all_alerts = alerts.list_alerts()
    assert len(all_alerts) == 1
    assert all_alerts.iloc[0]["alert_id"] == alert_id
    assert all_alerts.iloc[0]["acknowledged"] == False  # noqa: E712


def test_acknowledge_alert(isolated_data_dir):
    alert_id = alerts.raise_alert("Equipment", "EQ1", "Temperature", 110, "Critical")
    assert alerts.count_active_alerts() == 1

    ok = alerts.acknowledge_alert(alert_id)
    assert ok is True
    assert alerts.count_active_alerts() == 0


def test_acknowledge_unknown_alert_returns_false(isolated_data_dir):
    assert alerts.acknowledge_alert("A9999") is False


def test_count_critical_alerts_only_counts_unacknowledged_critical(isolated_data_dir):
    a1 = alerts.raise_alert("Equipment", "EQ1", "Temperature", 110, "Critical")
    alerts.raise_alert("Worker", "W1", "Risk Level", "High", "High")
    assert alerts.count_critical_alerts() == 1

    alerts.acknowledge_alert(a1)
    assert alerts.count_critical_alerts() == 0


def test_repeated_alert_count(isolated_data_dir):
    alerts.raise_alert("Equipment", "EQ1", "Temperature", 110, "Critical")
    alerts.raise_alert("Equipment", "EQ1", "Vibration", 9, "Critical")
    alerts.raise_alert("Equipment", "EQ2", "Temperature", 90, "Warning")
    assert alerts.repeated_alert_count("EQ1") == 2
    assert alerts.repeated_alert_count("EQ2") == 1
    assert alerts.repeated_alert_count("EQ3") == 0


def test_list_alerts_filters_by_source_type_and_severity(isolated_data_dir):
    alerts.raise_alert("Worker", "W001", "Risk Level", "High", "High")
    alerts.raise_alert("Equipment", "EQ1", "Temperature", 110, "Critical")

    worker_alerts = alerts.list_alerts(source_type="Worker")
    assert len(worker_alerts) == 1
    assert worker_alerts.iloc[0]["source_id"] == "W001"

    critical_alerts = alerts.list_alerts(severity="Critical")
    assert len(critical_alerts) == 1
    assert critical_alerts.iloc[0]["source_id"] == "EQ1"
