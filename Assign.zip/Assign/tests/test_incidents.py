from src import data_loader, incidents


def _add(worker_id="W001", severity=2, department="Underground", incident_type="Fall",
         status="Open", **overrides):
    kwargs = dict(
        worker_id=worker_id, date="2026-01-01", time="08:00", shift="Day",
        location="Shaft 1", department=department, incident_type=incident_type,
        severity=severity, injury_status="First Aid", lost_time_injury=False,
        cause="Unsafe act", corrective_action="Briefing", incident_status=status,
    )
    kwargs.update(overrides)
    return incidents.add_incident(**kwargs)


def test_add_incident_success(isolated_data_dir):
    incident_id, error = _add()
    assert error is None
    assert incident_id == "INC0001"


def test_add_incident_invalid_severity_rejected(isolated_data_dir):
    incident_id, error = _add(severity=9)
    assert incident_id is None
    assert "Severity" in error


def test_add_incident_invalid_status_rejected(isolated_data_dir):
    incident_id, error = _add(status="Not A Status")
    assert incident_id is None
    assert "status" in error.lower()


def test_high_severity_incident_raises_critical_alert(isolated_data_dir):
    incident_id, error = _add(severity=5)
    assert error is None
    alerts_df = data_loader.load_alerts()
    assert len(alerts_df) == 1
    assert alerts_df.iloc[0]["source_id"] == incident_id
    assert alerts_df.iloc[0]["severity"] == "Critical"


def test_low_severity_incident_does_not_raise_alert(isolated_data_dir):
    _add(severity=2)
    assert data_loader.load_alerts().empty


def test_search_incidents_filters_by_department(isolated_data_dir):
    _add(department="Underground", incident_type="Fall")
    _add(department="Opencast", incident_type="Fire")
    results = incidents.search_incidents(department="Opencast")
    assert len(results) == 1
    assert results.iloc[0]["incident_type"] == "Fire"


def test_search_incidents_text_search_matches_location_or_cause(isolated_data_dir):
    _add(location="Shaft 1", cause="Unsafe act")
    _add(location="Pit A", cause="Equipment failure")
    results = incidents.search_incidents(search_text="equipment")
    assert len(results) == 1
    assert results.iloc[0]["location"] == "Pit A"


def test_analyse_incident_trends_counts_high_critical(isolated_data_dir):
    _add(severity=5)
    _add(severity=2)
    trends = incidents.analyse_incident_trends()
    assert trends["high_critical_count"] == 1
    assert trends["by_department"]["Underground"] == 2


def test_analyse_incident_trends_empty(isolated_data_dir):
    trends = incidents.analyse_incident_trends()
    assert trends["high_critical_count"] == 0
    assert trends["by_department"].empty
