"""
Run the app's logic against new_data/*.csv and report PASS/FAIL per feature.

    python check_new_dataset.py

Works on a temporary COPY of new_data, so neither new_data/ nor data/ is changed.
"""
import shutil
import sys
import tempfile
import traceback
from pathlib import Path

import pandas as pd

from src import config

SRC = Path(__file__).resolve().parent / "new_data"
tmp = Path(tempfile.mkdtemp())
for f in SRC.glob("*.csv"):
    shutil.copy(f, tmp / f.name)

# point every CSV path at the temp copy (same trick tests/conftest.py uses)
attrs = ["USERS_CSV", "WORKERS_CSV", "INCIDENTS_CSV", "EQUIPMENT_CSV",
         "MAINTENANCE_CSV", "RISK_CSV", "ALERTS_CSV"]
schemas = {}
for a in attrs:
    old = getattr(config, a)
    new = tmp / old.name
    schemas[new] = config.SCHEMAS[old]
    setattr(config, a, new)
config.SCHEMAS = schemas
config.DATA_DIR = tmp

from src import (alerts, analysis, auth, condition_monitoring, data_loader,  # noqa: E402
                 equipment, incidents, maintenance, risk, rules, workers)

results = []


def check(name):
    def deco(fn):
        try:
            fn()
            results.append((name, True, ""))
        except Exception as e:  # noqa: BLE001
            results.append((name, False, f"{type(e).__name__}: {e}\n{traceback.format_exc(limit=3)}"))
        return fn
    return deco


@check("Schema: every CSV loads with the right columns")
def _():
    for a in attrs:
        p = getattr(config, a)
        df = data_loader.load_csv(p)
        assert list(df.columns) == config.SCHEMAS[p], p.name
        assert len(df) > 0, f"{p.name} is empty"


@check("Login: valid users, wrong password, disabled account")
def _():
    s, err = auth.login("admin2", "test1234")
    assert s and s.role == "Administrator" and err is None
    assert auth.login("admin2", "wrong")[0] is None
    s, err = auth.login("disabled2", "test1234")
    assert s is None and "disabled" in err.lower()
    for u, role in [("safety2", "Safety Officer"), ("mining2", "Mining Engineer"),
                    ("maint2", "Maintenance Engineer"), ("manager2", "Manager")]:
        s, _ = auth.login(u, "test1234")
        assert s and s.role == role, u


@check("Workers: view, filter, summary, add (valid + invalid)")
def _():
    assert len(workers.view_workers()) == 62
    assert len(workers.view_workers(department="Surface")) > 0
    workers.unsafe_conditions_summary()
    wid, err = workers.add_worker("New Person", "Surface", "Fitter", "Day", 90, "Current", 2, 1, 0, 0)
    assert err is None and wid == "W903", wid        # continues after W902
    assert workers.add_worker("X", "Surface", "Fitter", "Day", 150, "Current", 2, 1, 0, 0)[1]
    # edge workers: best = Low, worst = High/Critical
    w = data_loader.load_workers().set_index("worker_id")
    assert w.loc["W901", "risk_level"] == "Low"
    assert w.loc["W902", "risk_level"] in ("High", "Critical")


@check("Incidents: search, trends, add (severity 5 raises alert)")
def _():
    assert len(incidents.search_incidents()) == 45
    incidents.search_incidents(search_text="Fire")
    incidents.analyse_incident_trends()
    before = alerts.count_active_alerts()
    iid, err = incidents.add_incident("W001", "2026-10-01", "10:00", "Day", "Pit A", "Surface",
                                      "Fall", 5, "Lost Time", True, "Unsafe act", "Review")
    assert err is None and iid == "INC0046", iid
    assert alerts.count_active_alerts() == before + 1
    assert incidents.add_incident("W001", "2026-10-01", "10:00", "Day", "Pit A", "Surface",
                                  "Fall", 9, "None", False, "x", "y")[1]


@check("Equipment: view, filter, get, add + update (no duplicate)")
def _():
    assert len(equipment.view_equipment()) == 29
    assert equipment.get_equipment("TRK-901") is not None
    ok, err = equipment.add_or_update_equipment("NEW-001", "Loader", "Volvo", 500, 50, 2, 30,
                                                "OK", "OK", "OK", "Up to date", 10)
    assert ok, err
    equipment.add_or_update_equipment("NEW-001", "Loader", "Volvo", 600, 50, 2, 30,
                                      "OK", "OK", "OK", "Up to date", 10)
    df = data_loader.load_equipment()
    assert (df["equipment_id"] == "NEW-001").sum() == 1


@check("Rules: threshold boundaries (80/100 C, 5/8 mm/s)")
def _():
    assert rules.classify_temperature(79.9) == "Normal"
    assert rules.classify_temperature(80.0) == "Warning"
    assert rules.classify_temperature(100.0) == "Warning"    # Critical is strictly ABOVE 100
    assert rules.classify_temperature(100.1) == "Critical"
    assert rules.classify_vibration(4.9) == "Normal"
    assert rules.classify_vibration(5.0) == "Warning"
    assert rules.classify_vibration(8.0) == "Warning"        # Critical is strictly ABOVE 8
    assert rules.classify_vibration(8.1) == "Critical"


@check("Availability: zero operating hours does not crash")
def _():
    v = rules.calculate_availability(0.0, 0.0)
    assert v == v   # not NaN
    analysis.answer_question("equipment_lowest_availability")


@check("Condition monitoring: run on all equipment")
def _():
    res = condition_monitoring.run_condition_monitoring()
    assert res is not None


@check("Maintenance: monitoring run, attention list, add, complete")
def _():
    summary = maintenance.run_maintenance_monitoring(raise_alerts=True)
    assert len(summary) > 0
    maintenance.equipment_needing_attention(summary)
    mid, err = maintenance.add_maintenance_record("TRK-901", "2026-11-01", "Preventive",
                                                  "Test", "T. Phala", "2026-12-01")
    assert err is None and mid, err
    assert maintenance.add_maintenance_record("NOPE-1", "2026-11-01", "Preventive",
                                              "Test", "T. Phala", "2026-12-01")[1]
    recs = data_loader.load_maintenance()
    open_id = recs[recs["status"] != "Completed"].iloc[0]["maintenance_id"]
    assert maintenance.complete_maintenance_record(open_id, "2026-10-20")
    assert not maintenance.complete_maintenance_record("M9999", "2026-10-20")


@check("Risk: submit assessment, list, High raises alert")
def _():
    out, err = risk.submit_risk_assessment("Worker", "W902", 5, 5, "U001")
    assert err is None and out["classification"] == "Critical" and out["warning"]
    assert risk.submit_risk_assessment("Worker", "W902", 9, 1, "U001")[1]
    assert len(risk.list_risk_assessments()) >= 31


@check("Alerts: list, filter, count, acknowledge")
def _():
    assert len(alerts.list_alerts()) > 0
    alerts.list_alerts(active_only=True)
    alerts.list_alerts(severity="Critical")
    alerts.count_critical_alerts()
    first = data_loader.load_alerts().iloc[0]
    alerts.repeated_alert_count(first["source_id"])
    aid = alerts.raise_alert("Equipment", "TRK-901", "Temperature", 95, "Warning")
    assert alerts.acknowledge_alert(aid)


for key, meta in analysis.QUESTION_REGISTRY.items():
    def make(k=key):
        @check(f"Analysis: {meta['label']}")
        def _():
            r = analysis.answer_question(k)
            assert r["result_type"] in ("metric", "table", "chart")
    make()

# --- report ---------------------------------------------------------------
passed = sum(ok for _, ok, _ in results)
print(f"\nResults on new_data/: {passed}/{len(results)} checks passed\n")
for name, ok, detail in results:
    print(("PASS  " if ok else "FAIL  ") + name)
    if not ok:
        print("      " + detail.replace("\n", "\n      "))
shutil.rmtree(tmp, ignore_errors=True)
sys.exit(0 if passed == len(results) else 1)
