"""
Mining Health, Safety and Equipment Monitoring Application.

Entry point: handles RBAC login (src/auth.py) then renders a role-filtered
navigation menu (src/config.ROLE_PERMISSIONS) built from the views package.

Run with:  streamlit run app.py
"""

import streamlit as st

from src import auth
from src.error_logging import log_errors
from views import alerts, dashboard, equipment,import_data, incidents, maintenance, reports, risk, users, workers

st.set_page_config(page_title="Mining HSE Monitor", page_icon="⛏️", layout="wide")

if "session" not in st.session_state:
    st.session_state.session = None


def render_login() -> None:
    st.title("⛏️ Mining Health, Safety & Equipment Monitoring")
    st.caption("Sign in to continue")

    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Log in", width='stretch')

    if submitted:
        session, error = auth.login(username, password)
        if error:
            st.error(error)
        else:
            st.session_state.session = session
            st.rerun()

    st.info("Demo accounts: admin / safety1 / mining1 / maint1 / manager1 — password: password123")


session = st.session_state.session

if session is None:
    render_login()
    st.stop()

# feature key -> (url slug, title, icon, render function). Every page is
# wrapped in log_errors so a bug in one page can't take down the whole app -
# it logs to logs/app.log and shows a friendly message instead of a raw
# traceback. url_path is given explicitly because every view module's
# function is named `render`, and st.Page would otherwise infer the same
# URL pathname for all of them and raise a collision error.
PAGE_DEFS = [
    ("dashboard", "dashboard", "Dashboard", "📊", log_errors("Dashboard")(dashboard.render)),
    ("dashboard", "alerts", "Alerts", "🔔", log_errors("Alerts")(alerts.render)),
    ("worker_data", "workers", "Workers", "🧑‍🏭", log_errors("Workers")(workers.render)),
    ("incidents", "incidents", "Safety Incidents", "🚨", log_errors("Safety Incidents")(incidents.render)),
    ("equipment", "equipment", "Equipment", "🚜", log_errors("Equipment")(equipment.render)),
    ("maintenance", "maintenance", "Maintenance", "🛠️", log_errors("Maintenance")(maintenance.render)),
    ("risk", "risk", "Risk Assessment", "⚠️", log_errors("Risk Assessment")(risk.render)),
    ("reports", "reports", "Interactive Analysis", "📈", log_errors("Interactive Analysis")(reports.render)),
    ("manage_users", "users", "Manage Users", "🔐", log_errors("Manage Users")(users.render)),
    ("import_data", "import", "Import Dataset", "📥", log_errors("Import Dataset")(import_data.render)), 
]

pages = [
    st.Page(fn, title=title, icon=icon, url_path=slug)
    for perm, slug, title, icon, fn in PAGE_DEFS
    if auth.has_permission(session, perm)
]

with st.sidebar:
    st.markdown(f"**{session.full_name}**")
    st.caption(session.role)
    if st.button("Log out", width='stretch'):
        st.session_state.session = None
        st.rerun()

nav = st.navigation(pages)
nav.run()
