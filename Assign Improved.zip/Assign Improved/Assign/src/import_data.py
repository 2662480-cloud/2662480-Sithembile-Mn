"""Import a new dataset: upload a CSV and replace one of the data/*.csv files."""

import pandas as pd
import streamlit as st

from src import config, data_loader
from views import shared


def _datasets() -> dict:
    """Name shown in the dropdown -> the CSV file it replaces.

    users.csv is left out on purpose: replacing it could lock everyone out.
    (Looked up inside a function so tests can redirect config paths.)
    """
    return {
        "Workers": config.WORKERS_CSV,
        "Safety incidents": config.INCIDENTS_CSV,
        "Equipment": config.EQUIPMENT_CSV,
        "Maintenance records": config.MAINTENANCE_CSV,
        "Risk assessments": config.RISK_CSV,
        "Alerts": config.ALERTS_CSV,
    }


def clean_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Tidy header names so 'Worker ID ' becomes 'worker_id'."""
    df = df.copy()
    df.columns = (
        df.columns.astype(str).str.strip().str.lower().str.replace(r"[\s-]+", "_", regex=True)
    )
    return df


def check_columns(df: pd.DataFrame, required: list[str]) -> tuple[list[str], list[str]]:
    """Return (missing, extra) columns compared with what the app expects."""
    missing = [c for c in required if c not in df.columns]
    extra = [c for c in df.columns if c not in required]
    return missing, extra


def render() -> None:
    shared.section_header(
        "📥 Import Dataset",
        "Replace one of the app's datasets with your own CSV file.",
    )

    datasets = _datasets()
    name = st.selectbox("Step 1 - Which dataset are you importing?", list(datasets))
    path = datasets[name]
    required = config.SCHEMAS[path]

    st.markdown("**Your file's header row needs these columns** (any order):")
    st.code(", ".join(required), language=None)

    uploaded = st.file_uploader("Step 2 - Upload your CSV file", type="csv")
    if uploaded is None:
        return

    try:
        df = clean_columns(pd.read_csv(uploaded))
    except Exception as exc:  # unreadable / not really a CSV
        st.error(f"Could not read that file as a CSV: {exc}")
        return

    st.markdown(f"**Step 3 - Check your data** ({len(df)} rows)")
    st.dataframe(df.head(10), width="stretch")

    missing, extra = check_columns(df, required)
    if missing:
        st.error(
            "Missing column(s): " + ", ".join(missing)
            + ". Fix the header row in your file and upload it again."
        )
        return
    if extra:
        st.warning("These extra column(s) will be ignored: " + ", ".join(extra))
    if df.empty:
        st.warning("This file has no rows - importing it will empty the dataset.")

    st.warning(f"Importing replaces ALL current {name.lower()} data.")
    if st.button(f"Step 4 - Import {len(df)} rows", type="primary"):
        data_loader.save_csv(path, df)  # keeps only the expected columns, in order
        st.success(f"{name} replaced with {len(df)} rows. Open the Dashboard to see the results.")
        st.info(
            "Tip: existing alerts were raised from the OLD data. Re-run the condition / "
            "maintenance checks to raise fresh ones, or import an alerts file too."
        )
