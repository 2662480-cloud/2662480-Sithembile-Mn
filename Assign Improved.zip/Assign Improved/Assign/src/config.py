"""
Central configuration: file paths and CSV schemas for every entity.

Column lists here are the single source of truth for the data layer -
data_loader.py uses them to create empty CSVs with the right structure,
and data_generator.py uses them to know what to populate.
"""

from pathlib import Path

# --- Paths -------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

USERS_CSV = DATA_DIR / "users.csv"
WORKERS_CSV = DATA_DIR / "workers.csv"
INCIDENTS_CSV = DATA_DIR / "safety_incidents.csv"
EQUIPMENT_CSV = DATA_DIR / "equipment.csv"
MAINTENANCE_CSV = DATA_DIR / "maintenance_records.csv"
RISK_CSV = DATA_DIR / "risk_assessments.csv"
ALERTS_CSV = DATA_DIR / "alerts.csv"

# --- Schemas (column order matters - it is the CSV header order) -------

SCHEMAS = {
    USERS_CSV: [
        "user_id", "username", "password_hash", "full_name", "role", "active",
    ],
    WORKERS_CSV: [
        "worker_id", "name", "department", "job_role", "shift",
        "ppe_compliance_pct", "safety_training_status", "fatigue_level",
        "safety_observations", "near_misses", "previous_incidents", "risk_level",
    ],
    INCIDENTS_CSV: [
        "incident_id", "worker_id", "date", "time", "shift", "location",
        "department", "incident_type", "severity", "injury_status",
        "lost_time_injury", "cause", "corrective_action", "incident_status",
    ],
    EQUIPMENT_CSV: [
        "equipment_id", "equipment_type", "manufacturer", "operating_hours",
        "temperature", "vibration", "fuel_consumption", "brake_status",
        "tyre_status", "engine_status", "maintenance_status", "downtime_hours",
    ],
    MAINTENANCE_CSV: [
        "maintenance_id", "equipment_id", "scheduled_date", "completed_date",
        "maintenance_type", "description", "status", "technician", "next_due_date",
    ],
    RISK_CSV: [
        "risk_id", "related_type", "related_id", "likelihood", "consequence",
        "risk_score", "classification", "assessment_date", "assessed_by",
    ],
    ALERTS_CSV: [
        "alert_id", "timestamp", "source_type", "source_id", "parameter",
        "value", "severity", "message", "acknowledged",
    ],
}

# --- Roles / access control ---------------------------------------------

ROLES = [
    "Administrator",
    "Safety Officer",
    "Mining Engineer",
    "Maintenance Engineer",
    "Manager",
]

# Matches Table 1 in the project brief.
ROLE_PERMISSIONS = {
    "Administrator": {
        "dashboard", "worker_data", "incidents", "equipment",
        "maintenance", "risk", "reports", "manage_users","import_data", 
    },
    "Safety Officer": {
        "dashboard", "worker_data", "incidents", "risk", "reports",
    },
    "Mining Engineer": {
        "dashboard", "worker_data", "incidents", "equipment",
        "maintenance", "risk", "reports",
    },
    "Maintenance Engineer": {
        "dashboard", "equipment", "maintenance", "reports",
    },
    "Manager": {
        "dashboard", "worker_data", "incidents", "equipment",
        "maintenance", "risk", "reports",
    },
}

# --- Business-rule thresholds (educational prototype values only) -------

TEMP_WARNING_C = 80
TEMP_CRITICAL_C = 100

VIBRATION_WARNING_MMS = 5
VIBRATION_CRITICAL_MMS = 8

AVAILABILITY_LOW_THRESHOLD_PCT = 80
MAINTENANCE_DUE_SOON_DAYS = 7
REPEATED_ALERT_THRESHOLD = 3

RISK_BANDS = [
    (1, 4, "Low"),
    (5, 9, "Medium"),
    (10, 16, "High"),
    (17, 25, "Critical"),
]

EQUIPMENT_TYPES = [
    "Haul Truck", "Loader", "Excavator", "Drilling Machine",
    "Bulldozer", "Scraper Winch", "Crusher", "Conveyor",
]

DEPARTMENTS = ["Underground", "Opencast", "Processing", "Surface", "Engineering"]

SHIFTS = ["Day", "Night"]
