"""
Build a brand-new, independent test dataset (new_data/*.csv).

Run from the project root:   python make_new_dataset.py

It reuses the project's own generator functions (so the schemas and rule logic
match exactly) but with a different random seed, different dataset sizes,
different people/user accounts, and a handful of hand-written "edge case" rows
that sit exactly on the rule thresholds in src/config.py.
Your real data/*.csv files are never touched.
"""
import random
from pathlib import Path

import pandas as pd

from src import config, data_generator as g, rules

OUT = Path(__file__).resolve().parent / "new_data"
SEED = 2026


def build():
    random.seed(SEED)

    # --- different people / accounts -----------------------------------
    g.FIRST_NAMES[:] = ["Anele", "Busisiwe", "Cebo", "Dineo", "Elias", "Fikile", "Given",
                        "Hlengiwe", "Itumeleng", "Jabu", "Khanyi", "Lwazi", "Masego", "Neo"]
    g.LAST_NAMES[:] = ["Ngcobo", "Pillay", "Naidoo", "van Wyk", "Jacobs", "Moyo",
                       "Tau", "Mkhize", "Botha", "Ledwaba", "Seboko", "Venter"]

    users = pd.DataFrame([
        {"user_id": f"U{i:03d}", "username": u, "password_hash": g._hash_password("test1234"),
         "full_name": n, "role": r, "active": a}
        for i, (u, n, r, a) in enumerate([
            ("admin2", "Anele Ngcobo", "Administrator", True),
            ("safety2", "Dineo Pillay", "Safety Officer", True),
            ("mining2", "Elias Naidoo", "Mining Engineer", True),
            ("maint2", "Fikile van Wyk", "Maintenance Engineer", True),
            ("manager2", "Given Jacobs", "Manager", True),
            ("disabled2", "Old Account", "Safety Officer", False),   # disabled-login test
        ], start=1)
    ])

    # --- different sizes -------------------------------------------------
    workers = g.generate_workers(60)
    equipment = g.generate_equipment(25)
    maintenance = g.generate_maintenance_records(equipment)
    equipment = g.refine_equipment_maintenance_status(equipment, maintenance)
    incidents = g.generate_incidents(workers, 45)

    # --- edge cases sitting exactly on thresholds -------------------------
    edge = [
        # id,        type,         temp, vib,  hrs,    down
        ("TRK-901", "Haul Truck",  80.0, 5.0, 1000.0, 200.0),    # exactly WARNING limits, 80% availability
        ("LDR-901", "Loader",     100.0, 8.0, 1000.0, 201.0),    # top of the Warning band (Critical is strictly above), <80% availability
        ("EXC-901", "Excavator",   79.9, 4.9, 1000.0,   0.0),    # just below warning, 100% availability
        ("CNV-901", "Conveyor",    60.0, 2.0,    0.0,   0.0),    # zero operating hours (divide-by-zero risk)
    ]
    rows = []
    for eid, etype, t, v, hrs, down in edge:
        rows.append({"equipment_id": eid, "equipment_type": etype, "manufacturer": "Epiroc",
                     "operating_hours": hrs, "temperature": t, "vibration": v,
                     "fuel_consumption": 50.0, "brake_status": "OK", "tyre_status": "OK",
                     "engine_status": "OK", "maintenance_status": "Up to date",
                     "downtime_hours": down})
    equipment = pd.concat([equipment, pd.DataFrame(rows)], ignore_index=True)

    # equipment with NO maintenance record at all (CNV-901 has none on purpose)
    extra_m = []
    n = len(maintenance) + 1
    for eid in ("TRK-901", "LDR-901", "EXC-901"):
        extra_m.append({"maintenance_id": f"M{n:04d}", "equipment_id": eid,
                        "scheduled_date": "2026-01-10", "completed_date": "",
                        "maintenance_type": "Preventive", "description": "Edge-case record",
                        "status": "Overdue", "technician": "T. Phala",
                        "next_due_date": "2026-02-01"})
        n += 1
    maintenance = pd.concat([maintenance, pd.DataFrame(extra_m)], ignore_index=True)

    # worker edge cases: best case and worst case
    edge_workers = [
        ("W901", "Test Best", 100.0, 1, 0, 0),
        ("W902", "Test Worst", 0.0, 5, 5, 5),
    ]
    wrows = []
    for wid, name, ppe, fat, nm, prev in edge_workers:
        wrows.append({"worker_id": wid, "name": name, "department": "Surface", "job_role": "Fitter",
                      "shift": "Day", "ppe_compliance_pct": ppe, "safety_training_status": "Current",
                      "fatigue_level": fat, "safety_observations": 0, "near_misses": nm,
                      "previous_incidents": prev,
                      "risk_level": rules.evaluate_worker_risk(ppe, fat, nm, prev)})
    workers = pd.concat([workers, pd.DataFrame(wrows)], ignore_index=True)

    risk = g.generate_risk_assessments(workers, equipment, incidents, users, 30)
    alerts = g.generate_alerts(workers, equipment, maintenance, risk)

    # --- write -----------------------------------------------------------
    OUT.mkdir(exist_ok=True)
    files = {
        config.USERS_CSV: users, config.WORKERS_CSV: workers,
        config.EQUIPMENT_CSV: equipment, config.MAINTENANCE_CSV: maintenance,
        config.INCIDENTS_CSV: incidents, config.RISK_CSV: risk, config.ALERTS_CSV: alerts,
    }
    for path, df in files.items():
        df.to_csv(OUT / path.name, index=False, columns=config.SCHEMAS[path])
        print(f"{path.name:<25} {len(df):>4} rows")
    print(f"\nWritten to {OUT}")


if __name__ == "__main__":
    build()
